# Alice Shares Her Coffeelicious Research - RDM 1 - Medium - 500 Points
- an API that helps her share data in a secure and best possible way.

## Tech Stack
- [Anaconda Python3](https://www.anaconda.com/distribution/) or [Python3](https://www.python.org/downloads/)
- Flask

## Installing and running locally
Run the following commands -
- Get into the root folder

```CMD
- docker-compose up -d
- docker compose up
```
or

```CMD
- docker-compose up
```

## Requests arguments:
- http://127.0.0.1:5000/listspecies - GET

- http://127.0.0.1:5000/providedata - POST - {"coffee_name":"robusta"} - JSON DATA

## Verification CLI
- Provided with the code is a cli and a config.json file to test the api
- open anaconda prompt and run 
```CMD
- cli.py 
```