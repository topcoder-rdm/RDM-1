def main():
    import json
    import requests
    with open('config.json', "r") as f:
        config = json.load(f)
    print("Processing")
    base_url = config['api_base_url']
    if config['list_coffees']:
        print("Getting All coffee names from Server!")
        api_endpoint = base_url + '/listspecies'
        response = requests.get(api_endpoint)
        if response.status_code == 200:
            print(json.loads(response.text))
        else:
            print(json.loads(response.text))
        
    if config['provide_details']:
        print("Getting coffee details from Server!")
        api_endpoint = base_url + '/providedata'
        coffee_name = input("Enter Cofee Name:")
        response = requests.post(api_endpoint,json={'coffee_name': coffee_name})
        if response.status_code == 200:
            print(json.loads(response.text))
        else:
            print(json.loads(response.text))


if __name__ == '__main__':
    main()
