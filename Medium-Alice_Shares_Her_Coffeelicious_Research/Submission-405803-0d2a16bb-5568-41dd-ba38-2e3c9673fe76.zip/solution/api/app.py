import requests
from flask import Flask, request
from flask_restful import Api, Resource
from services import get_coffee_details,get_coffee_names


app = Flask(__name__)
api = Api(app)

class ListCoffee(Resource):
    def get(self):
        response = get_coffee_names()
        return response

class DescribeCofee(Resource):
    def post(self):
        coffee_name = request.get_json()['coffee_name']
        if coffee_name:
            response = get_coffee_details(coffee_name)
            return response
        else:
            return "Empty Coffee Name!"
        

api.add_resource(ListCoffee,'/listspecies')
api.add_resource(DescribeCofee,'/providedata')
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)