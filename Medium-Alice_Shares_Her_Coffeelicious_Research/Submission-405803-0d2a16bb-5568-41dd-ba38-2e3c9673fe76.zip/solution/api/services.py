def get_coffee_names():
    import os
    dir_path = r'data'+ os.sep + 'e-commerce' + os.sep+ 'coffee'
    print(dir_path)
    coffees = [f.name.title() for f in os.scandir(dir_path) if f.is_dir() ]
    return coffees

def get_coffee_details(coffee_name):
    import os
    dir_path = r'data'+ os.sep + 'e-commerce' + os.sep+ 'coffee' 
    coffee_path = os.path.join(dir_path,coffee_name.lower()+os.sep+'about')
    print(coffee_path)
    desc=""
    price =""
    if not os.path.exists(coffee_path):
        print("Incorrect Coffee name!")
    else:
        with open(os.path.join(coffee_path,'desc.txt'),'r') as f:
            desc = f.read()
        with open(os.path.join(coffee_path,'price.txt'),'r') as f:
            price = f.read()
    return {"description":desc,"price":price}