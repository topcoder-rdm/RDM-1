require("dotenv").config();

const _ = require("lodash");

const http = require("http");
const config = require("config");
const express = require("express");

const cross = require("cors");
const bodyParser = require("body-parser");

const routes = require("./src/route");
const logger = require("./src/common/logger");
const errorMiddleware = require("./src/common/error.middleware");

const app = express();
const httpServer = http.Server(app);

app.set("port", config.PORT);

app.use(cross());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

const apiRouter = express.Router();

_.each(routes, (verbs, url) => {
  _.each(verbs, (def, verb) => {
    const actions = [];
    const { method } = def;
    if (!method) {
      throw new Error(`${verb.toUpperCase()} ${url} method is undefined.`);
    }

    actions.push(async (req, res, next) => {
      try {
        await method(req, res, next);
      } catch (e) {
        next(e);
      }
    });

    logger.info(
      `Endpoint discovered: [${verb.toLocaleUpperCase()} /${
        config.API_VERSION
      }${url}]`
    );
    apiRouter[verb](`/${config.API_VERSION}${url}`, actions);
  });
});

app.use("/", apiRouter);
app.use(errorMiddleware());
app.use("*", (req, res) => {
  const pathKey = req.baseUrl.substr(config.API_VERSION.length + 1);
  const route = routes[pathKey];
  if (route) {
    res
      .status(405)
      .json({ messsage: "The requested method is not supported." });
  } else {
    res
      .status(404)
      .json({ message: "The requested resource can not be found." });
  }
});

httpServer.listen(app.get("port"), () => {
  logger.info(`Express server listening on port ${app.get("port")}`);
});
