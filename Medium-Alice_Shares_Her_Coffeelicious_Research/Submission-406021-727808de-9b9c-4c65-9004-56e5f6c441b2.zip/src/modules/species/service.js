const config = require("config");
const path = require("path");
const fs = require("fs");

const rootPath = path.join(config.DATA_DIRECTORY, "e-commerce", "coffee");

async function list() {
  return new Promise((resolve, reject) => {
    fs.readdir(rootPath, (err, files) => {
      if (err || files == null) {
        reject({
          status: 400,
          message:
            err.code == "ENOENT"
              ? "Data directory is missing"
              : "Invalid request. Please try again later.",
        });
      } else {
        files = files.map((file) => get(file));
        Promise.all(files).then((results) => resolve(results));
      }
    });
  });
}

async function get(name) {
  return new Promise((resolve, reject) => {
    fs.lstat(path.resolve(rootPath, name), (err, stats) => {
      if (err)
        reject({
          status: 400,
          message: "Invalid species name!",
        });
      else {
        const description = path.join(rootPath, name, "about", "desc.txt");
        const price = path.join(rootPath, name, "about", "price.txt");
        const imagesDirectory = path.join(rootPath, name, "images");

        Promise.all([
          readText(description),
          readText(price),
          listImages(imagesDirectory),
        ]).then((results) => {
          resolve({
            name,
            description: results[0],
            price: results[1],
            images: results[2],
          });
        });
      }
    });
  });
}

async function download(name, imageId) {
  try {
    return new Promise((resolve, reject) => {
      const imagePath = path.resolve(
        path.join(rootPath, name, "images", imageId + ".png")
      );
      fs.lstat(path.resolve(rootPath, name), (err) => {
        if (err) {
          reject({
            status: 400,
            message: `No image for species ${name} with imageId ${imageId} found.`,
          });
        } else {
          resolve({
            path: imagePath,
            filename: imageId + ".png",
          });
        }
      });
    });
  } catch (err) {
    throw new Error({
      status: 400,
      message: "Not found",
    });
  }
}

async function readText(file) {
  return new Promise((resolve, reject) => {
    fs.readFile(file, "utf8", (err, data) => {
      if (err) reject(err);
      else resolve(data);
    });
  });
}

async function listImages(path) {
  return new Promise((resolve, reject) => {
    fs.readdir(path, (err, files) => {
      if (err) {
        resolve([]);
      }
      resolve(files.map((file) => file.substr(0, file.length - 4)));
    });
  });
}

module.exports = {
  list,
  get,
  download,
};
