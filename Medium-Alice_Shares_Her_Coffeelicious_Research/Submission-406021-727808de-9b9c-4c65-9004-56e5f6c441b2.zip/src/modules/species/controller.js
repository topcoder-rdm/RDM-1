const { nextTick } = require("process");
const service = require("./service");

async function list(req, res, next) {
  try {
    res.json(await service.list());
  } catch (e) {
    next(e);
  }
}

async function get(req, res, next) {
  try {
    res.json(await service.get(req.params.name));
  } catch (e) {
    next(e);
  }
}

async function download(req, res, next) {
  try {
    let data = await service.download(req.params.name, req.params.id);
    res.download(data.path, data.filename);
  } catch (e) {
    next(e);
  }
}

module.exports = {
  list,
  get,
  download,
};
