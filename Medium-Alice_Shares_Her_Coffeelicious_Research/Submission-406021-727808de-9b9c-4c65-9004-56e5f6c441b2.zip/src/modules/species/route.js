const controller = require("./controller");

module.exports = {
  "/species": {
    get: {
      method: controller.list,
    },
  },
  "/species/:name": {
    get: {
      method: controller.get,
    },
  },
  "/species/:name/image/:id": {
    get: {
      method: controller.download,
    },
  },
};
