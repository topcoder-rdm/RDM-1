/**
 * default configuration
 */

module.exports = {
  PORT: process.env.PORT || 3000,
  DATA_DIRECTORY: process.env.DATA || "./data",
  API_VERSION: 1,
};
