# Coffee Species Api

## Install Software

- node 12.x
- npm 6.x
- docker

Configuration

Configuration for application is at config/default.js A .env file may be created to setup configuration as well

- PORT: the server part
- DATA: path to the directory e-commerce

Example .env file

```
PORT=3002
DATA=/home/username/data/
```

## Local Deployment

- open a terminal to the source code directory
- install dependencies with `npm install`
- run the app with `npm run start`

## Local Deployment with Docker

Running the app in a docker container requires attaching the e-commerce directory to a mounted volume. The dockerfile defines a "/data" volume. Here's how to do a local docker deployment

1. Open docker/docker-compose.yml in an editor
2. Modify line 11 from `../data:/data` so that the the first part points to the directory that has the e-commerce directory
3. run docker-compose up -d
