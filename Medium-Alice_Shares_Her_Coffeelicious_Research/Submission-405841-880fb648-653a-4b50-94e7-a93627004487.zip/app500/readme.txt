# setup app:

`cd docker`

`docker-compose up`

# Test app:
Get all species:  Get http://localhost:3000/
Get specific species data: Get http://localhost:3000/<speciesNameHere>, for example: http://localhost:3000/robusta

