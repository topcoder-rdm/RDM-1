var express = require('express');
var router = express.Router();
var fs = require('fs');
var config = require('config');
var path = require('path');

async function getAllSpecs () {
  return new Promise((resolve, reject) => {
    fs.readdir(config.dataPath + '/e-commerce/coffee', (err, files) => {
      if (err) {
        reject(err);
      }
      resolve(files)
    });
  });
}

async function getFilesOfPath(pathVal) {
  return new Promise((resolve, reject) => {
    fs.readdir(pathVal, (err, files) => {
      if (err) {
        reject(err);
      }
      resolve(files);
    });
  });
}

/**
 * Get species info by species name
 * @param {String} specName species name
 */
async function getSpecsDataByName (specName) {
  const speciesFolder = `../${config.dataPath}/e-commerce/coffee/${specName}`;
  const speciesImagesFolder = `../${config.dataPath}/e-commerce/coffee/${specName}/images`;
  console.log('speciesFolder:', path.join(__dirname, speciesFolder))
  if (fs.existsSync(path.join(__dirname, speciesFolder))) {
    const pngFiles = await getFilesOfPath(path.join(__dirname, speciesImagesFolder));
    if (pngFiles && pngFiles.length > 0) {
      const imageFilePath = path.join(__dirname, `${speciesImagesFolder}/${pngFiles[0]}`);
      const pngFileContent = fs.readFileSync(imageFilePath, 'binary');
      return pngFileContent;
    } else {
      return '';
    }
  } else {
    return '';
  }
}

/* GET all species. */
router.get('/', async function(req, res, next) {
  res.json(await getAllSpecs());
});

/* GET species by name */
router.get('/:specName', async function(req, res, next) {
  const pngFileContent = await getSpecsDataByName(req.params.specName);
  res.writeHead(200, 'Ok');
  res.write(pngFileContent,'binary');
  res.end();
});

module.exports = router;
