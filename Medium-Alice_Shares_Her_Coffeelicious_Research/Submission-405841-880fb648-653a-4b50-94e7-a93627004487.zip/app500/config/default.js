module.exports = {
    dataPath: './data'
}
