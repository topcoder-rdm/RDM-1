const http = require('http'),
    url = require('url'),
    service = require('./service');

const server = http.createServer();

const HOST = '0.0.0.0';
const PORT = 4000;

// Hard coded username & password
const AUTH = 'admin:admin';

server.on('request', async (req, res) => {
  const _url = url.parse(req.url, true);  
  if (req.method === 'GET') {
    /* Check whether request is authenticated or not */
    var userpass = new Buffer((req.headers.authorization || '').split(' ')[1] || '', 'base64').toString();
    if (userpass !== AUTH) {
      res.writeHead(401, {'WWW-Authenticate': 'Basic realm="nope"'});
      res.end('HTTP Error 401 Unauthorized: Access id denied');
      return;
    }
    /* Check whether end point returns all */
    if (_url.path === '/') {
      const data = await service.all();
      res.writeHead(200, { 'Content-Type': 'application/json'});
      res.end(JSON.stringify(data));
    }
    /* End point for getting single species */
    else {
      try {
	var name = _url.path.replace('/', '');
	const data = await service.get(name);
	res.writeHead(200, { 'Content-Type': 'application/json'});
	res.end(JSON.stringify(data));
      } catch (err) {
	res.writeHead(404, { 'Content-Type': 'application/json'});
	res.end(JSON.stringify({'error': `The species ${name} not found`}));
      }
    }
  }
});

server.listen(PORT, HOST, () => {
  console.log(`Server is listening on ${HOST}:${PORT}`);
})
