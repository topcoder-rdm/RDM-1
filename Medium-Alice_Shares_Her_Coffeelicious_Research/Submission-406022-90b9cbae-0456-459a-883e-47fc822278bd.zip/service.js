const fs = require('fs'),
      path = require('path'),
      util = require('util'),
      readdir = util.promisify(fs.readdir),
      readFile = util.promisify(fs.readFile),
      folder = path.join(__dirname, 'e-commerce/coffee/');

/**
 * Get image for recipe
 *
 * @param {string} Name of the recipe
 * @returns {string} The base64 encoded image data
 */
async function readImage (name) {
  const files = await readdir(path.join(path.join(path.join(folder, name), 'images')));
  const data = await readFile(path.join(path.join(path.join(folder, name), 'images'), files[0]));
  return data.toString('base64');
}

/**
 * Get description of the species
 *
 * @param {string} Name of the recipe
 * @returns {string} The description text
 */
async function readDescription (name) {
  const desc = await readFile(path.join(path.join(path.join(folder, name), 'about'), "desc.txt"));
  return desc.toString();
}

/**
 * Get all available species
 *
 * @returns {Array} The array of species
 */
async function getAll () {
  const files = await readdir(folder);
  return files.map((el, i) => {
    return { name: el }
  });
}

/**
 * Get specie by name
 *
 * @param {string} Name of the recipe
 * @returns {object} Recipe which found
 */
async function getOne (name) {
  const desc = await readDescription(name);
  const img = await readImage(name);
  return {desciption: desc, image: img};
}

module.exports = {
  all: getAll,
  get: getOne
};
