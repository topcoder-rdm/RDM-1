
## Dependencies
- docker

## Run
```
docker-compose up
```

## Endpoints

```
GET http://localhost:3000/species

[
    "arabica",
    "liberica",
    "robusta"
]
```


```
GET http://localhost:3000/species/arabica

{
    "species": "arabica",
    "about": "This coffee bean with low caffeine and a smoother taste is aromatic and delicious. 80% of the coffee in the world is produced from these types of beans",
    "price": 120.99,
    "images": [
        "http://localhost:3000/species/arabica/30sdfknl09123-arabica-23ij09d67as5123.png"
    ]
}
```

```
http://localhost:3000/species/arabica/30sdfknl09123-arabica-23ij09d67as5123.png


<binary data>
```