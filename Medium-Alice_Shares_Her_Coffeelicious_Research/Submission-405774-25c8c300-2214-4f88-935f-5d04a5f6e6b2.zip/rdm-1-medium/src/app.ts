import express from 'express';
import fs from 'fs';
import bodyParser from 'body-parser';
import { domainMiddleware } from './middlewares/domainMiddleware';
import { errorHandlerMiddleware } from './middlewares/errorHandlerMiddleware';
import { notFoundHandlerMiddleware } from './middlewares/notFoundHandlerMiddleware';
import http from 'http';
import Path from 'path';
import { logger } from './common/logger';
import { BASE_DOMAIN, PORT } from './config';
import { wrapExpress } from './common/wrapExpress';
import { readData } from './data';
import { NotFoundError } from './common/errors';

const app = express();
app.set('port', PORT);
app.use(domainMiddleware);
app.use(bodyParser.json());

app.get(
  '/species',
  wrapExpress((req, res) => {
    res.json(readData().map((x) => x.species));
  })
);

function getSpecies(species: string) {
  const ret = readData().find((x) => x.species === species);
  if (!ret) {
    throw new NotFoundError(`${species} not found`);
  }
  return ret;
}

app.get(
  '/species/:species',
  wrapExpress((req, res) => {
    const ret = getSpecies(req.params.species);
    res.json({
      ...ret,
      images: ret.images.map(
        (image) => `${BASE_DOMAIN}/species/${req.params.species}/${image.name}`
      ),
    });
  })
);

app.get(
  '/species/:species/:image',
  wrapExpress((req, res) => {
    const ret = getSpecies(req.params.species);
    const image = ret.images.find((x) => x.name === req.params.image);
    if (!image) {
      throw new NotFoundError('Image not found');
    }
    fs.createReadStream(image.path).pipe(res);
  })
);

app.use(errorHandlerMiddleware);
app.use(notFoundHandlerMiddleware);

const server = http.createServer(app);
server.listen(app.get('port'), '0.0.0.0', () => {
  logger.info(
    `Express HTTP server listening on port ${app.get('port')} in ${
      process.env.NODE_ENV
    } mode`
  );
});
