import fs from 'fs';
import Path from 'path';
import { CoffeeInfo } from './types';

const baseDir = Path.join(__dirname, '../e-commerce/coffee');

export function readData(): CoffeeInfo[] {
  return fs.readdirSync(baseDir).map((species) => {
    return {
      species,
      about: fs.readFileSync(
        Path.join(baseDir, species, 'about/desc.txt'),
        'utf8'
      ),
      price: Number(
        fs.readFileSync(Path.join(baseDir, species, 'about/price.txt'), 'utf8')
      ),
      images: fs
        .readdirSync(Path.join(baseDir, species, 'images'))
        .map((name) => ({
          name,
          path: Path.join(baseDir, species, 'images', name),
        })),
    };
  });
}
