import { Request, Response, NextFunction } from 'express';

export type Handler = (req: Request, res: Response, next: NextFunction) => void;

export interface CoffeeImage {
  name: string;
  path: string;
}

export interface CoffeeInfo {
  species: string;
  about: string;
  price: Number;
  images: CoffeeImage[];
}
