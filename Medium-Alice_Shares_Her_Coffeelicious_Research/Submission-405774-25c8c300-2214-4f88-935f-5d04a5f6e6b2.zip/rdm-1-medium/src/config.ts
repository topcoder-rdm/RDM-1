export const PORT = process.env.PORT || 3000;

export const BASE_DOMAIN = 'http://localhost:' + PORT;

export const LOG_LEVEL: 'debug' | 'info' =
  process.env.NODE_ENV === 'development' ? 'debug' : 'info';
