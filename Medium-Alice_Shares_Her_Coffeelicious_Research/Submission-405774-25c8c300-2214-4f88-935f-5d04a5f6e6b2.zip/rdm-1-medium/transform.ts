import fs from 'fs-extra';
import Path from 'path';

const targetDir = process.argv[process.argv.length - 1];

if (!targetDir) {
  throw new Error('provide a path');
}

const coffeeDir = Path.join(targetDir, 'e-commerce/coffee');

fs.readdirSync(targetDir).forEach((file) => {
  if (file.endsWith('.txt')) {
    const type = Path.basename(file, '.txt').toLowerCase();
    fs.moveSync(
      Path.join(targetDir, file),
      Path.join(coffeeDir, type, 'about/desc.txt')
    );
  } else if (file.endsWith('.png')) {
    const type = file.split('-')[1];
    fs.moveSync(
      Path.join(targetDir, file),
      Path.join(coffeeDir, type, 'images', file)
    );
  } else {
    throw new Error('Unsupported file: ' + file);
  }
});
