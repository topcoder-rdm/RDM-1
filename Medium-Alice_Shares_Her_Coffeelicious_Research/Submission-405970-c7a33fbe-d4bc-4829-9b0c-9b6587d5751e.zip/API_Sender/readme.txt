Hello, thank you for reading me!

Before starting this API, please copy the e-commerce/coffee/ folder to the same named folder here.
To start this API simply use docker-compose up
    (or docker-compose up -d)
To use this API to get the list of species simply use 
    curl http://localhost:5000/
To use this API to get the description and price of a species use
    curl http://localhost:5000/species_name
