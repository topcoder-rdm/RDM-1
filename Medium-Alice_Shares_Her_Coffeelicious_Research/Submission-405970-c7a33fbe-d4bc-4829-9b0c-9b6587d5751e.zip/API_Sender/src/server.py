import os, json
from flask import Flask
server = Flask(__name__)

#Route for the list of species folders
@server.route("/")
def coffeeList():
   #Start with an empty list
   result = {"species" : []}
   wrkDir = os.getcwd()
   for species in os.listdir(wrkDir):
      #Add each species to the list
      result["species"].append(species)
   #Return the result as JSON
   return json.dumps(result)

#Route for the individual species information
@server.route("/<species>")
def speciesData(species):
   wrkDir = os.getcwd()
   #Set a default return value
   result = "species " + species + " not found"
   try:
      if species in os.listdir(wrkDir):
         result = {}
         os.chdir(os.path.join(wrkDir, species, "about"))
         #Add the description to the return value
         fh = open("desc.txt", "r")
         result["description"] = fh.read()
         fh.close()
         #Add the price to the return value
         fh = open("price.txt", "r")
         result["price"] = fh.read()
         fh.close()
   except:
      result = "Something went wrong"
   finally:
      #Go back to the original work directory
      os.chdir(wrkDir)
   return json.dumps(result)

if __name__ == "__main__":
   os.chdir(os.path.join(os.getcwd(), "coffee"))
   server.run(host='0.0.0.0') 