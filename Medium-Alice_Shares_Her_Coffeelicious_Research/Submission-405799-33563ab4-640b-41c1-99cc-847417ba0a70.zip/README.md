# RDM med
## local test

```
docker-compose up -d
```

## API List

* The API should provide a way to list all the species available.
  * `GET /e-commerce/coffee`
* The API should provide a way to provide data for any specific species whose name would provide as an input.
  * `GET /e-commerce/coffee/spiecies/{spiecies}`
  * `GET /e-commerce/coffee/spiecies/{spiecies}/images`

#### The API should provide a way to list all the species available.

response

|parameter|description|
|-|-|
|spiecies|list of available all spiecies|

requests example
```
curl localhost:5000/e-commerce/coffee
```

response example
```
{
  "spiecies":[
    "arabica",
    "liberica",
    "robusta"
  ]
}
```

#### The API should provide a way to provide data for any specific species whose name would provide as an input.

response

|parameter|description|
|-|-|
|price|spiecies price|
|description|spiecies description|
|images| Access to get image file|

requests example
```
curl localhost:5000/e-commerce/coffee/spiecies/arabica
```

response example
```
{
  "description":"This coffee bean with low caffeine and a smoother taste is aromatic and delicious. 80% of the coffee in the world is produced from these types of beans",
  "images": "http://localhost:5000/e-commerce/coffee/spiecies/arabica/images",
  "price":"120.99"
}
```

#### download images

requests example
```
curl localhost:5000/e-commerce/coffee/spiecies/arabica/images
```
