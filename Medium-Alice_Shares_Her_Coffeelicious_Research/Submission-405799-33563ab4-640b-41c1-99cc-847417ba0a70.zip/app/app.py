import os
from flask import *

app = Flask(__name__)

def get_price(spiecies):
    return get_file_text("./e-commerce/coffee/{}/about/price.txt".format(spiecies))

def get_description(spiecies):
    return get_file_text("./e-commerce/coffee/{}/about/desc.txt".format(spiecies))

def get_image_path(spiecies):
    return os.listdir("./e-commerce/coffee/{}/images/".format(spiecies))[0]

def get_file_text(filePath):
    text = ""
    with open(filePath, "r") as f:
        for row in f:
            text += row.strip()
    return text

@app.route("/e-commerce/coffee")
def get_all_spiecies():
    return jsonify({"spiecies": os.listdir("./e-commerce/coffee")})

@app.route("/e-commerce/coffee/spiecies/<spiecies>")
def get_spiecies_data(spiecies):
    return jsonify(
        {
            "price": get_price(spiecies),
            "description": get_description(spiecies),
            "images": request.base_url + "/images"
        }
    )

@app.route("/e-commerce/coffee/spiecies/<spiecies>/images")
def get_images(spiecies):
    return send_from_directory(
        "./e-commerce/coffee/{}/images/".format(spiecies),
        get_image_path(spiecies),
        as_attachment=True
    )

if __name__ == "__main__":
    app.run(debug=False)
