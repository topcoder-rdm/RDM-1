# Alice Shares Her Coffeelicious Research - RDM 1 - Medium - 500 Points

- Postman collection: `RDM-1-Medium.postman_collection.json`
- Run app by command: `docker-compose up`
