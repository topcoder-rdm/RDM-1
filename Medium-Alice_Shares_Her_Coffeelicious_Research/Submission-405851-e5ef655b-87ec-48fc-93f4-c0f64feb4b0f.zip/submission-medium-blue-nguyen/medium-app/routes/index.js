const express = require('express');
const fs = require('fs');
const path = require('path');
const router = express.Router();

const isDirectory = (source) => fs.lstatSync(source).isDirectory();

router.get('/coffee/species', function (req, res, next) {
  const source = path.join(__dirname, '..', 'public', 'e-commerce', 'coffee');
  const species = fs
    .readdirSync(source, { withFileTypes: true })
    .filter((dir) => dir.isDirectory())
    .map((dir) => dir.name);
  res.json({ species });
});

router.get('/coffee/species/detail', function (req, res, next) {
  var fullUrl = req.protocol + '://' + req.get('host')
  console.log(fullUrl);
  const { name } = req.query;
  const specieSource = path.join(
    __dirname,
    '..',
    'public',
    'e-commerce',
    'coffee',
    name
  );
  if (!fs.existsSync(specieSource)) {
    return res.json();
  }
  const imageSource = path.join(specieSource, 'images');
  const aboutSource = path.join(specieSource, 'about');
  if (!fs.existsSync(imageSource) || !fs.existsSync(aboutSource)) {
    return res.json();
  }
  const images = fs
    .readdirSync(imageSource, { withFileTypes: true })
    .filter((item) => item.isFile())
    .map((item) => `${fullUrl}/e-commerce/coffee/${name}/images/${item.name}`);
  const desc = fs.readFileSync(path.join(aboutSource, 'desc.txt'), 'utf8');
  const price = parseFloat(
    fs.readFileSync(path.join(aboutSource, 'price.txt'), 'utf8')
  );
  res.json({
    images,
    desc,
    price,
    name,
  });
});

module.exports = router;
