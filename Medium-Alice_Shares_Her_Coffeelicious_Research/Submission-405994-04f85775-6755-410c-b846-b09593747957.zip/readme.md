# Usage

## Start API Server

Please put source files in the same directory to 'e-commerce' beforehand.
```
$ tree
.
├── Dockerfile
├── docker-compose.yml
├── e-commerce
│   └── coffee
│       └── arabica
│           ├── about
│           │   ├── desc.txt
│           │   └── price.txt
│           └── images
│               └── 30sdfknl09123-arabica-23ij09d67as5123.png
├── env.env
├── readme.md
└── src
    ├── app.py
    ├── coffee.py
    └── templates
        └── base.html
```

Then start with docker-compose command.
```
$ docker-compose up -d
```

Default port is '5000'. (see docker-compose.yml)  
Now you can access to the landing page 'http://localhost:5000/' .


## API Reference

- /api/list
    + get all of available species
    + return type: JSON
- /api/data/{species}
    + get specific coffee data
    + return type: JSON
- /images/{species}/{image}
    + get specific coffee image
    + return type: image file


## Example
```
$ curl localhost:5000/api/list
["arabica","liberica","robusta"]

$ curl localhost:5000/api/data/liberica
{"description":"Liberica is a low yield type of coffee compared to Arabica and Robusta","images":["/images/liberica/0alkdjoi-liberica-09xifbdsihlg312.png"],"name":"liberica","price":"89.99"}
```