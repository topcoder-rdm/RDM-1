import os
import logging
import coffee
from flask import Flask, jsonify, abort, send_file, render_template

logging.basicConfig(format='%(levelname)s:%(message)s', level=logging.WARNING)
logger = logging.getLogger("server")


# Flask app for API Server
def serve():
    if ('MY_APP_ROOT' in os.environ) is False:
        logger.error('set $MY_APP_ROOT')
        return
    root_dir = os.environ['MY_APP_ROOT']
    try:
        os.path.isdir(root_dir)
    except Exception as e:
        logger.error('invalid root folder. $MY_APP_ROOT={root_dir}')
        logger.error(e)
        return

    # load coffee data
    coffee_data = coffee.load_species(root_dir)
    coffee_list = list(coffee_data.keys())

    # start web app
    app = Flask(__name__)

    # landing page
    @app.route('/')
    def hello():
        api_endpoints = []
        api_endpoints += [{
            'url': '/api/list',
            'description': 'get all of available species',
            'sample_url': '/api/list'}]

        sample_coffee = 'nodata'
        sample_coffee_img = 'nodata'
        for name, data in coffee_data.items():
            if len(data.images) > 0:
                sample_coffee = name
                sample_coffee_img = data.images[0]
                break

        api_endpoints += [{
            'url': '/api/data/{species}',
            'description': 'get specific coffee data',
            'sample_url': '/api/data/{species}'.format(
                species=sample_coffee
            )}]
        api_endpoints += [{
            'url': '/images/{species}/{image}',
            'description': 'get specific coffee image',
            'sample_url': '/images/{species}/{image}'.format(
                species=sample_coffee,
                image=sample_coffee_img
            )}]
        return render_template(
            'base.html',
            title='API List',
            contents=api_endpoints)

    # api
    # get coffee list
    @app.route('/api/list')
    def fetch_list():
        return jsonify(coffee_list)

    # get specific coffee data
    # if it does not exist, return 404
    @app.route('/api/data/<species>')
    def fetch_data(species: str):
        if (species in coffee_data) is False:
            abort(404)
        d = coffee_data[species]
        resp = {
            'name': d.name,
            'price': d.get_price(),
            'description': d.desc,
            'images':
                list(map(lambda x: f'/images/{d.name}/{x}', d.images))
        }
        return jsonify(resp)

    # get coffee image
    @app.route('/images/<species>/<name>')
    def fetch_image(species, name):
        if (species in coffee_data) is False:
            abort(404)
        d = coffee_data[species]
        path = os.path.join(d.path, coffee.IMAGE_PATH, name)
        try:
            f = open(path, mode='rb')
            return send_file(f, mimetype='image/png')
        except Exception as e:
            logger.warning(path)
            logger.warning(e)
            abort(404)

    app.run(host='0.0.0.0')
    return app


if __name__ == '__main__':
    serve()
