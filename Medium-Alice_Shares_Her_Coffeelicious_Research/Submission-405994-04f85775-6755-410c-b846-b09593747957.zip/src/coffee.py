from fractions import Fraction
import os
import logging
import re
from typing import Dict


IMG_FILE_PATTERN = r'[^\-]+\-{species}\-[^\-]+\.png'
SPECIES_PATH = 'e-commerce/coffee/'
IMAGE_PATH = 'images/'
DESC_PATH = 'about/desc.txt'
PRICE_PATH = 'about/price.txt'

logging.basicConfig(format='%(levelname)s:%(message)s', level=logging.WARNING)
logger = logging.getLogger('logger_coffee')


class Coffee:
    def __init__(self, entry: os.DirEntry):
        self.path = entry.path
        self.name = os.path.basename(entry.name)
        self.desc = ''
        self.price = Fraction(0.0)
        self.images = []

        try:
            self.load_description()
            self.load_price()
            self.load_images()
        except Exception as e:
            logger.error(e)
            raise e

    def load_description(self):
        try:
            with open(os.path.join(self.path, DESC_PATH)) as f:
                self.desc = f.read()
        except IOError as e:
            raise e

    def load_price(self):
        try:
            with open(os.path.join(self.path, PRICE_PATH)) as f:
                price = f.read()
                self.price = Fraction(price)
        except IOError as e:
            raise e
        except ValueError as e:
            logger.error('price parse error')
            raise e

    def load_images(self):
        try:
            entries = os.scandir(os.path.join(self.path, IMAGE_PATH))
        except OSError as e:
            logger.warning(e)
            return
        pat = re.compile(IMG_FILE_PATTERN.format(species=self.name))
        for e in entries:
            # pick up only '*-{species}-*.png'
            if pat.fullmatch(e.name):
                self.images += [e.name]

    def get_price(self):
        # 1234.00
        v = self.price * 100
        a = int(v) // 100
        b = int(v) % 100
        return '{}.{:02d}'.format(a, b)


def load_species(root: str) -> Dict[str, Coffee]:
    """
    load all valid species in {root}/e-commerce/coffee/{species}
    """

    try:
        entries = os.scandir(os.path.join(root, SPECIES_PATH))
    except OSError as e:
        logger.error('failed to enumerate species')
        logger.error(e)
        return {}

    species = {}
    for e in entries:
        if e.is_file():
            continue
        if os.path.exists(os.path.join(e.path, DESC_PATH)) is False:
            continue
        if os.path.exists(os.path.join(e.path, PRICE_PATH)) is False:
            continue
        try:
            item = Coffee(e)
            species[item.name] = item
        except Exception:
            pass

    return species
