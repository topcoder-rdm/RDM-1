API to get list of coffee:
http://localhost:8000/api/coffee/list

API to get coffee data:
http://localhost:8000/api/coffee/getinfo?species=<species>

