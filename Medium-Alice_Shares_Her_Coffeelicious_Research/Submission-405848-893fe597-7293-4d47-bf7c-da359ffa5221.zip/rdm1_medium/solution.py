#!/usr/bin/python3

import http.server
import json
import pathlib
import re
import os
import sys

server_address = sys.argv[1]
server_port = int(sys.argv[2])

class CoffeeServer(http.server.BaseHTTPRequestHandler):
    datadir = "e-commerce/coffee"

    def do_GET(self):

        (request_path, request_param) = self.get_request_path_and_params(self.path)

        if request_path == "/api/coffee/list":
            self.list_species()
            return

        if request_path == "/api/coffee/getinfo":
            species = ""
            if "species" in request_param:
                species = request_param["species"]
            self.get_info(species)
            return

        if request_path.startswith("/images/"):
            self.serve_image(request_path[7:])
            return

        self.error(404, "The requested API does not exist: " + request_path)

    # API to list all the available coffee species
    # /api/coffee/list
    # sample API call: http://localhost:8000/api/coffee/list
    # sample output:
    # [
    #     "liberica",
    #     "arabica",
    #     "robusta"
    # ]
    def list_species(self):
        # all species available corresponds to all the folders in the datadir
        all_species = os.listdir(self.datadir)
        output = json.dumps(all_species)
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(bytes(output, "utf-8"))

    # API to get information about a coffee species
    # /api/coffee/getinfo?species=<species>
    # sample API call: http://localhost:8000/api/coffee/getinfo?species=robusta
    # sample output:
    # {
    #     "species": "robusta",
    #     "price": "110.99",
    #     "description": "This type of coffee, which contains 2.5% more caffeine than other types, has a pretty strong taste.",
    #     "images":
    #         [
    #             "http://localhost:8000/images/coffee-robusta-5ab4c8bee09125.7230548615217973109198.png"
    #         ]
    # }
    def get_info(self, species):
        if not os.path.exists(self.datadir+"/"+species):
            self.error(404, "The requested species does not exist")
            return
        price = pathlib.Path(self.datadir+"/"+species+"/about/price.txt").read_text()
        description = pathlib.Path(self.datadir+"/"+species+"/about/desc.txt").read_text()
        images = os.listdir(self.datadir+"/"+species+"/images/")
        coffee_info = {}
        coffee_info["species"] = species
        coffee_info["price"] = price
        coffee_info["description"] = description
        coffee_info["images"] = ["http://"+server_address+":"+str(server_port)+"/images/"+image for image in images]
        output = json.dumps(coffee_info)
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(bytes(output, "utf-8"))

    # To serve the coffee image according to the url returned by getinfo API
    def serve_image(self, image):
        p = re.compile(".*-(.*)-.*\.png")
        m = p.match(image)
        if not m:
            self.error(404, "The requested image does not exist")
            return
        species = m.group(1)
        filename = self.datadir+"/"+species+"/images/"+image
        if not os.path.exists(filename):
            self.error(404, "The requested image does not exist")
            return
        self.send_response(200)
        self.send_header("Content-Type", "image/png")
        self.end_headers()
        self.wfile.write(pathlib.Path(filename).read_bytes())

    # Parse the query string
    # Example: /api/coffee/getinfo?species=arabica
    # request_path will be /api/coffee/getinfo
    # the query parameters will be returned as a dictionary {species => arabica}
    def get_request_path_and_params(self, path):
        request_path = ""
        request_param = {}
        if not "?" in path:
            request_path = path
            return (request_path, request_param)
        (request_path, raw_param) = path.split("?")
        params = raw_param.split("&")
        for param in params:
            if not "=" in param:
                key = param
                value = ""
            else:
                (key, value) = param.split("=")
            request_param[key] = value
        return (request_path, request_param)

    def error(self, code=404, msg=""):
        self.send_response(code)
        self.end_headers()
        self.wfile.write(bytes(msg, "utf-8"))

def run():
    httpd = http.server.HTTPServer(("0.0.0.0", 8000), CoffeeServer)
    httpd.serve_forever()

run()

