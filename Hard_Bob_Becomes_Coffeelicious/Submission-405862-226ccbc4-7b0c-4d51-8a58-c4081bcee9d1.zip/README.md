# Deployment & Verification

1. Run `docker-compose up -d --build` to start app in docker container. alternativelly, you can start on localhost by running `npm install` followed by `npm start`.
2. Navigate to localhost:4200
3. Click on product card
4. Click Add to cart
5. Close product card and click cart button.
6. Complete checkout wizzard
7. Check dev tools to verify API communication
