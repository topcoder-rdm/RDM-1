export interface ProductModel {
    id: string,
    name: string,
    imageUrl: string,
    price: number,
    description: string
}