import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { ProductModel } from 'src/app/model/product.model';

@Injectable()
export class ProductsResolver implements Resolve<ProductModel[]> {
    constructor(private http: HttpClient) { }

    resolve() {
        return this.http.get<ProductModel[]>('https://alicecoffeeshop.devtesting.live/api/v1/Coffee/Species');
    }
}