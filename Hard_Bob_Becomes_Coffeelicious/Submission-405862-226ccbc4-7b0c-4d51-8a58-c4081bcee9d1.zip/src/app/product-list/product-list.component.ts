import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import { ProductModel } from 'src/app/model/product.model';
import { map } from 'rxjs/operators'
import { CartItem, CartService } from '../services/cart.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.scss']
})
export class ProductListComponent {
  products$ = new BehaviorSubject<CartItem[]>(null);
  selectedProduct: ProductModel = null;

  constructor(private route: ActivatedRoute, private cartService: CartService) {
    // Track route data
    route.data.pipe(
      map(({ products }) => this.generateCartItems(products))
    ).subscribe(this.products$);

    // Track cart contents
    cartService.cart$.pipe(
      map(() => this.generateCartItems(this.route.snapshot.data.products))
    ).subscribe(this.products$);
  }

  // Generate cart items for each product
  generateCartItems(products: ProductModel[]): CartItem[] {
    return products.map(product => ({
      product,
      quantity: (this.cartService.cart.find(x => x.product.id === product.id) || { quantity: 0 }).quantity
    }))
  }

  // Update cart item quantity
  changeQty = (entry: CartItem, delta) => {
    entry.quantity += delta;

    if (entry.quantity == 0) {
      this.cartService.remove(entry);
    }

    if (entry.quantity == 1) {
      this.cartService.add(entry);
    }
  }

  identity = (_, entry: CartItem) => entry.product.id;

}
