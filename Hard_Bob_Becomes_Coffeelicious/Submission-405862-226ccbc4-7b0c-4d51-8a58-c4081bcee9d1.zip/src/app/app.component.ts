import { HttpClient } from '@angular/common/http';
import { Component, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDrawer, MatStepper } from '@angular/material';
import { BehaviorSubject, pipe } from 'rxjs';
import { take } from 'rxjs/operators';
import { CartItem, CartService } from './services/cart.service';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss']
})
export class AppComponent {
  // Checkout form
  checkoutForm: FormGroup;
  // Cart items
  products$ = new BehaviorSubject<CartItem[]>(null);

  @ViewChild('stepper', { static: false }) stepper: MatStepper;
  @ViewChild('drawer', { static: false }) drawer: MatDrawer;

  constructor(fb: FormBuilder, private cartService: CartService, private http: HttpClient) {
    cartService.cart$.subscribe(this.products$);

    this.checkoutForm = fb.group({
      name: ['', Validators.required],
      address: ['', Validators.required],
      email: ['', Validators.compose([Validators.required, Validators.email])],
      phoneNo: ['', Validators.required]
    })
  }

  // Submit order to API
  submitOrder() {
    if (this.checkoutForm.valid && this.products$.value.length > 0) {
      this.http.post('https://alicecoffeeshop.devtesting.live/api/v1/Order/Coffee',
        // Payload
        Object.assign({}, this.checkoutForm.value,
          {
            items: this.products$.value.map(entry => ({
              qty: entry.quantity,
              id: entry.product.id
            }))
          }
        )).subscribe(() => {
          // Complete stepper and clear basket
          this.stepper.next();
          // Clear cart after drawer is closed
          this.drawer.closedStart.pipe(take(1)).subscribe(() => this.cartService.clear())
        });
    }
  }
}
