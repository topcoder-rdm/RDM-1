import { JsonPipe } from '@angular/common';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { ProductModel } from '../model/product.model';

export interface CartItem {
  product: ProductModel;
  quantity: number
}

// Cart service
@Injectable({
  providedIn: 'root'
})
export class CartService {
  // cart entries
  private _cart$ = new BehaviorSubject<CartItem[]>(this.load());

  // cart entries current calue
  get cart() { return this._cart$.value };

  // cart entries observable
  get cart$() { return this._cart$.asObservable() };

  // Add new cart entry
  add = (product: CartItem) => {
    this._cart$.next([...this._cart$.value, product]);
    this.save();
  }

  // Remove cart entry
  remove = (product: CartItem) => {
    this._cart$.next(this._cart$.value.filter(x => x.product.id !== product.product.id));
    this.save();
  }

  // Clear cart
  clear = () => {
    this._cart$.next([]);
    this.save();
  }

  private save() {
    window.sessionStorage.setItem('cart', JSON.stringify(this.cart));
  }

  private load() {
    return JSON.parse(window.sessionStorage.getItem('cart') || '[]')
  }
}
