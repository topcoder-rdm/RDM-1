
## Dependencies
- docker

## Run
```
docker-compose up
```

## Verification
Open http://localhost:9000/
 