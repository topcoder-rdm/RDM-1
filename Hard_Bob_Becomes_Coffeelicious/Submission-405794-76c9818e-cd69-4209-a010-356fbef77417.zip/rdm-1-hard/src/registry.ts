import { Registry } from 'typeless';

export const registry = new Registry();
