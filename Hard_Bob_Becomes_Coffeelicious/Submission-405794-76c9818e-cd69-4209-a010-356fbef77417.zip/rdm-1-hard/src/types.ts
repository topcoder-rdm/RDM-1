export interface RouteConfig {
  type: 'route';
  path: string | string[];
  exact?: boolean;
  auth: boolean;
  component: React.ReactElement<any>;
}

export interface Coffee {
  id: string;
  name: string;
  imageUrl: string;
  price: number;
  description: string;
}

export interface CardItem {
  id: string;
  qty: number;
}
