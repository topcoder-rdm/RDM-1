import * as Rx from 'src/rx';
import { Coffee } from 'src/types';

const API_URL = 'https://alicecoffeeshop.devtesting.live/api/v1';

export const api = {
  getAll: () =>
    Rx.ajax({
      url: API_URL + '/Coffee/Species',
      crossDomain: true,
    }).pipe(Rx.map((x) => x.response as Coffee[])),
  createOrder: (values: any) =>
    Rx.ajax({
      url: API_URL + '/Order/Coffee',
      method: 'POST',
      crossDomain: true,
      body: JSON.stringify(values),
      headers: {
        'content-type': 'application/json',
      },
    }).pipe(Rx.map((x) => x.response.orderId as string)),
};
