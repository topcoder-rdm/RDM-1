export const Theme = {
  text: '#3C485A',
  textDark: '#111',
  textLight: '#6c7481',
  bgLightGray: '#F2F3F7',
  border: '#8590A3',
  grayLight: '#D4D6DB',
  blue: '#33A9FF',
};
