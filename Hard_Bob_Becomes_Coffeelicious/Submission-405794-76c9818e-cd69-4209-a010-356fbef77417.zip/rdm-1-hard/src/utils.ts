export function getRelativeUrl(url: string) {
  // hot linking hack
  return url.split('.live')[1];
}
