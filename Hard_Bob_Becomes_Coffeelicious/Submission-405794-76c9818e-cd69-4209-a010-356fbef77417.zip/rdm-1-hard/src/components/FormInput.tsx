import * as React from 'react';
import { Form } from 'react-bootstrap';
import styled from 'styled-components';
import { FormContext } from 'typeless-form';

interface FormInputProps {
  className?: string;
  name: string;
  label: string;
  htmlType?: 'text' | 'password';
}

const _FormInput = (props: FormInputProps) => {
  const { className, name, label } = props;
  const {} = React.useContext(FormContext);
  const data = React.useContext(FormContext);
  if (!data) {
    throw new Error(`${name} cannot be used without FormContext`);
  }
  const hasError = data.touched[name] && !!data.errors[name];
  const value = data.values[name];
  return (
    <div className={className}>
      <Form.Group controlId={name}>
        <Form.Label>{label}</Form.Label>
        <Form.Control
          value={value == null ? '' : value}
          onBlur={() => data.actions.blur(name)}
          onChange={(e) => {
            data.actions.change(name, e.target.value);
          }}
          name="name"
          type="text"
          isInvalid={hasError}
        />
        <Form.Control.Feedback type="invalid">
          {data.errors[name]}
        </Form.Control.Feedback>
      </Form.Group>
    </div>
  );
};

export const FormInput = styled(_FormInput)``;
