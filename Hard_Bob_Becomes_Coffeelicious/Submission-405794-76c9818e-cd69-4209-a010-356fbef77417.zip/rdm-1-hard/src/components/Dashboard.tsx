import * as React from 'react';
import { Container } from 'react-bootstrap';
import styled from 'styled-components';
import { CartInfo } from './CartInfo';

interface DashboardProps {
  className?: string;
  children: React.ReactNode;
}

const Header = styled.div`
  display: flex;
  align-items: center;
`;

const _Dashboard = (props: DashboardProps) => {
  const { className, children } = props;
  return (
    <div className={className}>
      <Container>
        <Header>
          <h1>Coffee e-commerce</h1>
          <CartInfo />
        </Header>
        {children}
      </Container>
    </div>
  );
};

export const Dashboard = styled(_Dashboard)`
  display: block;
`;
