import * as R from 'remeda';

import * as React from 'react';
import { getGlobalState, GlobalActions } from 'src/features/global/interface';
import styled from 'styled-components';
import { useActions, useMappedState } from 'typeless';
import { Button } from 'react-bootstrap';
import { Link } from 'typeless-router';

interface CartInfoProps {
  className?: string;
}

const _CartInfo = (props: CartInfoProps) => {
  const { className } = props;
  const { cart, coffee } = useMappedState([getGlobalState], (x) => x);
  const { resetCart } = useActions(GlobalActions);
  const coffeeMap = R.indexBy(coffee, (x) => x.id);
  const count = cart.reduce((ret, x) => ret + x.qty, 0);
  const total = cart.reduce((ret, x) => ret + x.qty * coffeeMap[x.id].price, 0);

  return (
    <div className={className}>
      {count} {count == 1 ? 'item' : 'items'} (${total.toFixed(2)})
      {count > 0 && (
        <>
          <Button size="sm" onClick={resetCart}>
            reset
          </Button>
          <Link href="/checkout" style={{ marginLeft: 5 }}>
            <Button size="sm" variant="secondary">
              Checkout
            </Button>
          </Link>
        </>
      )}
    </div>
  );
};

export const CartInfo = styled(_CartInfo)`
  display: block;
  margin-left: auto;
`;
