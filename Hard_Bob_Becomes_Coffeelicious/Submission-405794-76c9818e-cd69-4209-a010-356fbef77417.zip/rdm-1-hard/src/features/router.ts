import { createUseRouter } from 'typeless-router';

export const useRouterModule = createUseRouter();
