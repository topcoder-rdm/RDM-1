import React from 'react';
import { RouteConfig } from 'src/types';
import { DetailsView } from './components/DetailsView';

// --- Routing ---

export const routeConfig: RouteConfig = {
  type: 'route',
  auth: false,
  path: '/coffee/:id',
  component: <DetailsView />,
};
