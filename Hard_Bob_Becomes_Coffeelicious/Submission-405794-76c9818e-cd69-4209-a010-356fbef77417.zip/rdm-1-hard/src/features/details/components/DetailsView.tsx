import React from 'react';
import * as R from 'remeda';
import { Button, Card } from 'react-bootstrap';
import { Dashboard } from 'src/components/Dashboard';
import { getGlobalState, GlobalActions } from 'src/features/global/interface';
import { useActions, useMappedState } from 'typeless';
import { getRouterState, Link } from 'typeless-router';

export function DetailsView() {
  const { addToCart } = useActions(GlobalActions);
  const { coffee } = useMappedState([getGlobalState], (x) => x);
  const id = useMappedState([getRouterState], (x) =>
    R.last(x.location!.pathname.split('/'))
  );
  const item = coffee.find((x) => x.id === id);
  if (!item) {
    return <Dashboard>Coffee not found</Dashboard>;
  }
  return (
    <Dashboard>
      <Link href="/">
        <Button>Back</Button>
      </Link>
      <Card key={item.id} style={{ marginTop: 20, maxWidth: 600 }}>
        <div style={{}}>
          <Card.Img variant="top" src={item.imageUrl} style={{ padding: 20 }} />
        </div>
        <Card.Body>
          <Card.Title>{item.name}</Card.Title>
          <Card.Subtitle className="mb-2 text-muted">
            ${item.price}
          </Card.Subtitle>
          <Card.Body>{item.description}.</Card.Body>
          <Button variant="primary" onClick={() => addToCart(item)}>
            Add To Cart
          </Button>
        </Card.Body>
      </Card>
    </Dashboard>
  );
}
