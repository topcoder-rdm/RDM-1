export const CheckoutSymbol = Symbol('Checkout');
export const CheckoutFormSymbol = Symbol('Checkout-form');
