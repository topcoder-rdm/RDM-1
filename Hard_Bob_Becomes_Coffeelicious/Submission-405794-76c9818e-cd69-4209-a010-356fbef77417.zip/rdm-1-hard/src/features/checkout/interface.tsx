import { createModule } from 'typeless';
import { CheckoutSymbol } from './symbol';

// --- Actions ---
export const [handle, CheckoutActions, getCheckoutState] = createModule(
  CheckoutSymbol
)
  .withActions({
    $init: null,
    $mounted: null,
    setIsLoading: (isLoading: boolean) => ({ payload: { isLoading } }),
    setSubmitted: (submittedId: string) => ({ payload: { submittedId } }),
  })
  .withState<CheckoutState>();

// --- Types ---
export interface CheckoutState {
  isSubmitted: boolean;
  submittedId: string;
  isLoading: boolean;
}
