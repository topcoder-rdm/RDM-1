import React from 'react';
import { RouteConfig } from 'src/types';
import { CheckoutView } from './components/CheckoutView';

// --- Routing ---

export const routeConfig: RouteConfig = {
  type: 'route',
  auth: false,
  path: '/checkout',
  component: <CheckoutView />,
};
