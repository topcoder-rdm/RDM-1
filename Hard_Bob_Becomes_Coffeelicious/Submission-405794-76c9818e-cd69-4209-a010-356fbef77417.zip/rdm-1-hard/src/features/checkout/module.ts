import * as Rx from 'src/rx';
import { api } from 'src/services/api';
import { getGlobalState, GlobalActions } from '../global/interface';
import { CheckoutFormActions, getCheckoutFormState } from './checkout-form';
import { handle, CheckoutState, CheckoutActions } from './interface';

// --- Epic ---
handle
  .epic()
  .on(CheckoutActions.$mounted, () => CheckoutFormActions.reset())
  .on(CheckoutFormActions.setSubmitSucceeded, () => {
    return Rx.concatObs(
      Rx.of(CheckoutActions.setIsLoading(true)),
      api
        .createOrder({
          ...getCheckoutFormState().values,
          items: getGlobalState().cart,
        })
        .pipe(
          Rx.mergeMap((id) => [
            CheckoutActions.setSubmitted(id),
            GlobalActions.resetCart(),
          ])
        ),
      Rx.of(CheckoutActions.setIsLoading(false))
    );
  });

// --- Reducer ---
const initialState: CheckoutState = {
  isSubmitted: false,
  submittedId: '',
  isLoading: false,
};

handle
  .reducer(initialState)
  .on(CheckoutActions.$init, (state) => {
    Object.assign(state, initialState);
  })
  .on(CheckoutActions.setIsLoading, (state, { isLoading }) => {
    state.isLoading = isLoading;
  })
  .on(CheckoutActions.setSubmitted, (state, { submittedId }) => {
    state.isSubmitted = true;
    state.submittedId = submittedId;
  });

// --- Module ---
export function useCheckoutModule() {
  handle();
}
