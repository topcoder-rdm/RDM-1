import React from 'react';
import { Button, Alert } from 'react-bootstrap';
import { Dashboard } from 'src/components/Dashboard';
import { FormInput } from 'src/components/FormInput';
import { useActions, useMappedState } from 'typeless';
import { Link } from 'typeless-router';
import {
  CheckoutFormActions,
  CheckoutFormProvider,
  useCheckoutForm,
} from '../checkout-form';
import { getCheckoutState } from '../interface';
import { useCheckoutModule } from '../module';

export function CheckoutView() {
  useCheckoutForm();
  useCheckoutModule();
  const { isLoading, isSubmitted, submittedId } = useMappedState(
    [getCheckoutState],
    (x) => x
  );
  const { submit } = useActions(CheckoutFormActions);

  const render = () => {
    if (isSubmitted) {
      return (
        <div>
          <Alert variant="success">Order submitted!</Alert>
          <div style={{ marginBottom: 20 }}>ID: {submittedId}</div>
          <Link href="/">
            <Button>Back</Button>
          </Link>
        </div>
      );
    }
    return (
      <CheckoutFormProvider>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            submit();
          }}
          style={{ maxWidth: 300 }}
        >
          <FormInput label="Name" name="name" />
          <FormInput label="Address" name="address" />
          <FormInput label="Email" name="email" />
          <FormInput label="Phone Number" name="phoneNumber" />
          <Button onClick={submit} type="submit" disabled={isLoading}>
            Submit
          </Button>
          <Link href="/" style={{ marginLeft: 10 }}>
            <Button variant="secondary">Back</Button>
          </Link>
        </form>
      </CheckoutFormProvider>
    );
  };

  return (
    <Dashboard>
      <h2>Checkout</h2>
      {render()}
    </Dashboard>
  );
}
