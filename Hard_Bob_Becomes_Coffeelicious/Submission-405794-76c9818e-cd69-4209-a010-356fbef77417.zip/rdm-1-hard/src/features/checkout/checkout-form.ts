import { createForm } from 'typeless-form';
import { CheckoutFormSymbol } from './symbol';

interface CheckoutForm {
  name: string;
  address: string;
  email: string;
  phoneNumber: string;
}

const emailReg = /^[a-zA-Z0-9._\-+]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;

export const [
  useCheckoutForm,
  CheckoutFormActions,
  getCheckoutFormState,
  CheckoutFormProvider,
] = createForm<CheckoutForm>({
  symbol: CheckoutFormSymbol,
  validator(errors, data) {
    if (!data.name) {
      errors.name = 'This field is required';
    }
    if (!data.address) {
      errors.address = 'This field is required';
    }
    if (!data.email) {
      errors.email = 'This field is required';
    } else if (!emailReg.test(data.email)) {
      errors.email = 'Invalid email';
    }
    if (!data.phoneNumber) {
      errors.phoneNumber = 'This field is required';
    }
  },
});
