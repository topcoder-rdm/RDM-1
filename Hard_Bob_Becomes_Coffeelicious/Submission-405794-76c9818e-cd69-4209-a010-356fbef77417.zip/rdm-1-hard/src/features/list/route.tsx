import React from 'react';
import { RouteConfig } from 'src/types';
import { ListView } from './components/ListView';

// --- Routing ---

export const routeConfig: RouteConfig = {
  type: 'route',
  auth: false,
  path: '/',
  component: <ListView />,
};
