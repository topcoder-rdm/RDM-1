import React from 'react';
import { Button, Card } from 'react-bootstrap';
import { Dashboard } from 'src/components/Dashboard';
import { getGlobalState } from 'src/features/global/interface';
import { useMappedState } from 'typeless';
import { Link } from 'typeless-router';

export function ListView() {
  const { coffee } = useMappedState([getGlobalState], (x) => x);

  return (
    <Dashboard>
      <div style={{ display: 'flex', flexWrap: 'wrap' }}>
        {coffee.map((item) => (
          <Card key={item.id} style={{ width: 300, margin: 5 }}>
            <div style={{ height: 300 }}>
              <Card.Img
                variant="top"
                src={item.imageUrl}
                style={{ padding: 20 }}
              />
            </div>
            <Card.Body>
              <Card.Title>{item.name}</Card.Title>
              <Card.Subtitle className="mb-2 text-muted">
                ${item.price}
              </Card.Subtitle>
              <Link href={'/coffee/' + item.id}>
                <Button variant="primary">View</Button>
              </Link>
            </Card.Body>
          </Card>
        ))}
      </div>
    </Dashboard>
  );
}
