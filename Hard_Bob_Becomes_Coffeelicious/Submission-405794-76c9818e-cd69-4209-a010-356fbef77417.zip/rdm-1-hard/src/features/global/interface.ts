import { CardItem, Coffee } from 'src/types';
import { createModule } from 'typeless';
import { GlobalSymbol } from './symbol';

// --- Actions ---
export const [handle, GlobalActions, getGlobalState] = createModule(
  GlobalSymbol
)
  .withActions({
    $mounted: null,
    loaded: (coffee: Coffee[]) => ({ payload: { coffee } }),
    addToCart: (coffee: Coffee) => ({ payload: { coffee } }),
    resetCart: null,
  })
  .withState<GlobalState>();

// --- Types ---
export interface GlobalState {
  isLoaded: boolean;
  coffee: Coffee[];
  cart: CardItem[];
}
