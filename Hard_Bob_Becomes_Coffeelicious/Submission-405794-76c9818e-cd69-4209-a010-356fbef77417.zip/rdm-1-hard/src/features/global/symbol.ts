export const GlobalSymbol = Symbol('global');
