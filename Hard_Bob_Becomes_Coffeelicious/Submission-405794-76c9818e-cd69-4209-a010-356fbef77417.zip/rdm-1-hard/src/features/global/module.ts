import * as Rx from 'src/rx';
import { api } from 'src/services/api';
import {
  getGlobalState,
  GlobalActions,
  GlobalState,
  handle,
} from './interface';

// --- Epic ---
handle
  .epic()
  .on(GlobalActions.$mounted, () =>
    api.getAll().pipe(Rx.map((x) => GlobalActions.loaded(x)))
  )
  .onMany([GlobalActions.addToCart, GlobalActions.resetCart], () => {
    localStorage.cart = JSON.stringify(getGlobalState().cart);
    return Rx.empty();
  });

function getInitialCart() {
  try {
    return JSON.parse(localStorage.cart);
  } catch (e) {
    return [];
  }
}

// --- Reducer ---
const initialState: GlobalState = {
  isLoaded: false,
  coffee: [],
  cart: getInitialCart(),
};

handle
  .reducer(initialState)
  .on(GlobalActions.addToCart, (state, { coffee }) => {
    const existing = state.cart.find((x) => x.id === coffee.id);
    if (existing) {
      existing.qty++;
    } else {
      state.cart.push({
        id: coffee.id,
        qty: 1,
      });
    }
  })
  .on(GlobalActions.resetCart, (state) => {
    state.cart = [];
  })
  .on(GlobalActions.loaded, (state, { coffee }) => {
    state.coffee = coffee;
    state.isLoaded = true;
  });

// --- Module ---
export function useGlobalModule() {
  handle();
}
