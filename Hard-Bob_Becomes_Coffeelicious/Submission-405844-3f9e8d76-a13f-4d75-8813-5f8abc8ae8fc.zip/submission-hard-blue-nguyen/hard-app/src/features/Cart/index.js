import {
  Button,
  Card,
  CardActions,
  CardContent,
  CardHeader,
  List,
  ListItem,
  ListItemSecondaryAction,
  ListItemText,
  Modal,
  TextField,
} from '@material-ui/core';
import Joi from 'joi';
import React, { useState } from 'react';
import api from '../../utils/api';
import './Cart.css';

const orderSchema = Joi.object({
  name: Joi.string().required(),
  address: Joi.string().required(),
  email: Joi.string()
    .email({ tlds: { allow: false } })
    .required(),
  phoneNo: Joi.string().required(),
  items: Joi.any(),
});

function Cart({ open, onClose, onFinishSubmit, orderedCoffees }) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [name, setName] = useState('');
  const [address, setAddress] = useState('');
  const [email, setEmail] = useState('');
  const [phoneNo, setPhoneNo] = useState('');
  const [error, setError] = useState(null);

  const handleSubmit = async () => {
    try {
      setIsSubmitting(true);
      const data = {
        name,
        address,
        email,
        phoneNo,
        items: Object.values(orderedCoffees).map((coffee) => ({
          id: coffee.id,
          qty: coffee.orderedUnits,
        })),
      };
      await orderSchema.validateAsync(data);
      const response = await api.createOrder({
        name,
        address,
        email,
        phoneNo,
        items: Object.values(orderedCoffees).map((coffee) => ({
          id: coffee.id,
          qty: coffee.orderedUnits,
        })),
      });
      console.log(response);
      onFinishSubmit();
    } catch (error) {
      console.log(error);
      setError(error.error || error.message);
    } finally {
      setIsSubmitting(false);
    }
  };
  const handleChangeName = (evt) => setName(evt.target.value);
  const handleChangeAddress = (evt) => setAddress(evt.target.value);
  const handleChangeEmail = (evt) => setEmail(evt.target.value);
  const handleChangePhoneNo = (evt) => setPhoneNo(evt.target.value);

  const totalPrice = Object.values(orderedCoffees).reduce((sum, item) => sum + item.price * item.orderedUnits, 0);

  return (
    <Modal className="cart" open={open} onClose={onClose}>
      <Card className="cart-content">
        <CardHeader title="Cart" />
        <CardContent>
          <h3>Your items</h3>
          <List className="list-order">
            {Object.values(orderedCoffees).map((coffee) => {
              const price = coffee.price * coffee.orderedUnits;
              return (
                <ListItem key={coffee.id}>
                  <img
                    className="coffee-image"
                    alt={coffee.name}
                    src={coffee.imageUrl}
                  />
                  <ListItemText
                    primary={coffee.name}
                    secondary={`${coffee.orderedUnits} units x 500gram`}
                  />
                  <ListItemSecondaryAction>
                    {price.toFixed(2)}$
                  </ListItemSecondaryAction>
                </ListItem>
              );
            })}
          </List>
          <div className="total-price-container">
            Total:
          <strong className="total-price">{totalPrice.toFixed(2)}$</strong>
          </div>
          <h3>Your information</h3>
          {isSubmitting ? (
            <div>Submitting order...</div>
          ) : (
            <form>
              <div className="user-form">
                <TextField
                  label="Name"
                  required
                  onChange={handleChangeName}
                  value={name}
                  autoFocus
                  error={!name}
                />
                <TextField
                  label="Address"
                  required
                  onChange={handleChangeAddress}
                  value={address}
                  error={!address}
                />
                <TextField
                  label="Email"
                  required
                  onChange={handleChangeEmail}
                  value={email}
                  error={!email}
                  autoComplete="email"
                />
                <TextField
                  label="Phone Number"
                  required
                  onChange={handleChangePhoneNo}
                  value={phoneNo}
                  error={!phoneNo}
                />
              </div>
              <small>
                Payment will be done on delivery to delivery personnel who will
                be carrying a card machine along with them. It can also be done
                with cash.
              </small>
              {error && <div className="error">{error}</div>}
            </form>
          )}
        </CardContent>
        <CardActions className="actions-group" disableSpacing>
          <Button
            color="primary"
            disabled={isSubmitting || !name || !email || !address || !phoneNo}
            onClick={handleSubmit}
          >
            Submit order
          </Button>
          <Button color="secondary" onClick={onClose}>
            Close
          </Button>
        </CardActions>
      </Card>
    </Modal>
  );
}

export default Cart;
