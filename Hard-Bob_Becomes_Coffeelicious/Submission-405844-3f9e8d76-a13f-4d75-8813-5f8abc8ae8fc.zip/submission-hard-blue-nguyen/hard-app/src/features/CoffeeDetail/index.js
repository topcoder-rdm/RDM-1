import {
  Button,
  Card,
  CardActions,
  CardContent,
  CardHeader,
  CardMedia,
  Modal,
  TextField,
  Typography,
} from '@material-ui/core';
import React, { useState } from 'react';
import './CoffeeDetail.css';

function CoffeeDetail({ open, onClose, onOrder, coffee }) {
  const [units, setUnits] = useState(0);

  const handleAddtoCoffeeDetail = () => {
    onOrder(coffee, units);
    setUnits(0);
  };

  const handleChangeUnits = (evt) => {
    setUnits(evt.target.value);
  };
  return (
    <Modal className="coffee-detail" open={open} onClose={onClose}>
      <Card className="coffee-detail-content">
        <CardHeader title={coffee.name} />
        <CardMedia
          className="coffee-image"
          image={coffee.imageUrl}
          title={coffee.name}
        />
        <CardContent>
          <Typography variant="body1" color="textPrimary" component="strong">
            {coffee.price}$ / 500gm
          </Typography>
          <Typography variant="body2" color="textSecondary" component="p">
            {coffee.description}
          </Typography>
          <div className="order-form">
            <div className="order-inputs">
              <TextField
                label="Unit"
                type="number"
                onChange={handleChangeUnits}
                value={units}
                inputProps={{ min: 0 }}
              />
              <span className="subtext">x 500 grams</span>
            </div>
          </div>
        </CardContent>
        <CardActions className="actions-group" disableSpacing>
          <Button
            color="primary"
            onClick={handleAddtoCoffeeDetail}
            disabled={units === 0}
          >
            Add to cart
          </Button>
          <Button color="secondary" onClick={onClose}>
            Cancel
          </Button>
        </CardActions>
      </Card>
    </Modal>
  );
}

export default CoffeeDetail;
