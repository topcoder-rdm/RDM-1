import {
  AppBar,
  Button,
  Card,
  CardActionArea,
  CardActions,
  CardContent,
  CardMedia,
  Container,



  Toolbar
} from '@material-ui/core';
import CssBaseline from '@material-ui/core/CssBaseline';
import React, { useEffect, useState } from 'react';
import './App.css';
import Cart from './features/Cart';
import CoffeeDetail from './features/CoffeeDetail';
import api from './utils/api';

function App() {
  const [listCoffee, setListCoffee] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);
  const [orderedCoffees, setOrderedCoffees] = useState({});
  const [isCartOpened, setIsCartOpened] = useState(false);

  useEffect(() => {
    const cachedListCoffee = JSON.parse(
      localStorage.getItem('listCoffee') || JSON.stringify([])
    );
    setListCoffee(cachedListCoffee);

    const loadListCoffee = async () => {
      try {
        if (cachedListCoffee.length === 0) {
          setIsLoading(true);
        }
        const listCoffee = await api.listCoffeeSpecies();
        localStorage.setItem('listCoffee', JSON.stringify(listCoffee));
        setListCoffee(listCoffee);
      } finally {
        setIsLoading(false);
      }
    };
    loadListCoffee();
  }, []);

  const handleSelectItem = (item) => () => {
    setSelectedItem(item);
  };
  const handleCloseCoffeeDetail = () => {
    setSelectedItem(null);
  };

  const handleAddOrderedCoffee = (coffee, units) => {
    const newOrder = { ...orderedCoffees };
    if (newOrder[coffee.id]) {
      newOrder[coffee.id].orderedUnits += parseInt(units);
    } else {
      newOrder[coffee.id] = {
        ...coffee,
        orderedUnits: parseInt(units),
      };
    }
    setOrderedCoffees(newOrder);
  };

  const handleQuickAdd = (coffee) => () => {
    handleAddOrderedCoffee(coffee, 1);
  };

  const handleOpenCart = () =>
    setIsCartOpened(true && Object.values(orderedCoffees).length > 0);
  const handleCloseCart = () => setIsCartOpened(false);
  const handleFinishSubmit = () => {
    setOrderedCoffees({});
    handleCloseCart();
  };

  return (
    <React.Fragment>
      <CssBaseline />
      <AppBar position="fixed">
        <Toolbar>
          <h1 className="app-title">Coffee Shop</h1>
          <Button
            color="inherit"
            onClick={handleOpenCart}
            disabled={Object.values(orderedCoffees).length === 0}
          >
            Cart
          </Button>
        </Toolbar>
      </AppBar>
      <Container className="main-container" maxWidth="md">
        <CssBaseline />
        {isLoading ? (
          <div>Loading...</div>
        ) : (
          <div className="coffee-list">
            {listCoffee.map((item) => {
              return (
                <Card key={item.id} className="coffee-item">
                  <CardActionArea onClick={handleSelectItem(item)}>
                    <CardMedia
                      className="coffee-image"
                      image={item.imageUrl}
                      title={item.name}
                    />
                    <CardContent>
                      <div className="coffee-name">{item.name}</div>
                      <div className="coffee-price">{item.price}$ / 500gm</div>
                    </CardContent>
                  </CardActionArea>
                  <CardActions>
                    <Button
                      size="small"
                      color="primary"
                      onClick={handleQuickAdd(item)}
                    >
                      Add 1 unit
                    </Button>
                  </CardActions>
                </Card>
              );
            })}
          </div>
        )}
      </Container>
      {selectedItem && (
        <CoffeeDetail
          open={!!selectedItem}
          onClose={handleCloseCoffeeDetail}
          onOrder={handleAddOrderedCoffee}
          coffee={selectedItem}
        />
      )}
      <Cart
        open={isCartOpened && Object.values(orderedCoffees).length > 0}
        onClose={handleCloseCart}
        onFinishSubmit={handleFinishSubmit}
        orderedCoffees={orderedCoffees}
      />
    </React.Fragment>
  );
}

export default App;
