const API_URL = 'https://alicecoffeeshop.devtesting.live/api/v1';
const listCoffeeSpecies = () => {
  const requestURL = `${API_URL}/coffee/species`;
  const options = {
    method: 'GET',
  };
  return fetch(requestURL, options).then((res) => res.json());
};

const createOrder = (data) => {
  const requestURL = `${API_URL}/order/coffee`;
  const options = {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(data),
  };
  return fetch(requestURL, options).then((res) => res.json());
};

export default { listCoffeeSpecies, createOrder };
