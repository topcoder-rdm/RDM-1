# Bob Becomes Coffeelicious - RDM 1 - Hard - 800 Points
- start an e-commerce website.

## Tech Stack
- [Anaconda Python3](https://www.anaconda.com/distribution/) or [Python3](https://www.python.org/downloads/)
- Django

## Installing and running locally
Run the following commands -
- Get into the root folder

```CMD
- docker-compose up -d
- docker compose up
```
or

```CMD
- docker-compose up
```

## Verification CLI
- Open [this](http://127.0.0.1:8000/) link web browser and  
