module.exports = {
  presets: [
    '@dr.pogodin/react-utils/config/babel/node-ssr',
  ],
};
