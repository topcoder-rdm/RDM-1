/**
 * Summary of the current order and link to the checkout page.
 */

import React from 'react';

import {
  Button,
  PT,
  Throbber,
  useAsyncData,
  useGlobalState,
} from '@dr.pogodin/react-utils';

import { calcOrder, loadCoffeeSpecies } from 'services';

import './style.scss';

function Item({
  id,
  name,
  amount,
  price,
}) {
  return (
    <div key={id}>
      {name}: {amount}g &rArr; ${price.toFixed(2)}
    </div>
  );
}

Item.propTypes = {
  id: PT.string.isRequired,
  name: PT.string.isRequired,
  amount: PT.number.isRequired,
  price: PT.number.isRequired,
};

export default function Cart() {
  const { data } = useAsyncData('coffeeSpicies', loadCoffeeSpecies);
  const [order] = useGlobalState('order', {});

  let content;
  if (!data || data.error) content = <Throbber />;
  else {
    const oo = calcOrder(order, data);
    if (!oo.list.length) {
      content = <p>nothing yet</p>;
    } else {
      oo.list.sort((a, b) => a.name.localeCompare(b.name));
      content = (
        <div>
          {oo.list.map(Item)}
          <div styleName="total">Total: ${oo.price.toFixed(2)}</div>
          <Button to="/checkout">Checkout</Button>
        </div>
      );
    }
  }

  return (
    <div styleName="container">
      <div styleName="name">Your Selection:</div>
      {content}
    </div>
  );
}
