/**
 * Root component of the app.
 */
/* global window */

import React from 'react';
import Routes from 'routes';

import { MetaTags, useGlobalState } from '@dr.pogodin/react-utils';

export default function Application() {
  const [order, setOrder] = useGlobalState('order', {});

  /* Makes order persistent in the local storage. */
  React.useEffect(() => {
    const pastOrder = window.localStorage.getItem('coffeeOrder');
    if (pastOrder) setOrder(JSON.parse(pastOrder));
  }, [setOrder]);
  React.useEffect(() => {
    window.localStorage.setItem('coffeeOrder', JSON.stringify(order));
  }, [order]);

  return (
    <>
      <MetaTags
        title="TC RDM #1 - HARD - Bob Becomes Coffeelicious"
        description="TC RDM #1 - HARD - Bob Becomes Coffeelicious"
      />
      <Routes />
    </>
  );
}
