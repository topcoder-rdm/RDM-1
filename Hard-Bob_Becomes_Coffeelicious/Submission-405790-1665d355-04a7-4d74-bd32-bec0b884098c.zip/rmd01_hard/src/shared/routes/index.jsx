/**
 * Root router of the app.
 */
/* eslint-disable react/jsx-props-no-spreading */

import React from 'react';
import { Route, Switch } from 'react-router-dom';

import Error404 from 'pages/Error404';
import Checkout from 'pages/Checkout';
import CoffeePage from 'pages/CoffeePage';
import Landing from 'pages/Landing';

export default function Routes() {
  return (
    <Switch>
      <Route exact path="/" component={Landing} />
      <Route exact path="/checkout" component={Checkout} />
      <Route exact path="/coffee/:id" component={CoffeePage} />
      <Error404 />
    </Switch>
  );
}
