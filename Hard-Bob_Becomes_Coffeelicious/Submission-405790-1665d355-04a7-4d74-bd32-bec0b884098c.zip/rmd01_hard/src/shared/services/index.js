import { _, api, config } from '@dr.pogodin/react-utils';

/**
 * Calculates order details.
 * @param {object} order
 * @param {object[]} coffeeData
 * @return {object}
 */
export function calcOrder(order, coffeeData) {
  const data = {};
  coffeeData.forEach((item) => {
    data[item.id] = item;
  });
  const res = { list: [], price: 0 };
  _.forOwn(order, (datum, id) => {
    if (datum.amount > 0) {
      const price = (datum.amount * data[id].price) / 500;
      res.list.push({
        id,
        amount: datum.amount,
        name: data[id].name,
        price,
      });
      res.price += price;
    }
  });
  return res;
}

/**
 * Loads coffee species from remote API.
 * @return {Promise<object[]>} Resolves to array of coffee species.
 */
export async function loadCoffeeSpecies() {
  const url = `${config.API_BASE}/api/v1/Coffee/Species`;
  try {
    const { data } = await api(url);
    return data;
  } catch (error) {
    console.error(error);
    return { error: 'Failed to load coffee species' };
  }
}

/**
 * Sends order to API.
 * @param {object} order
 * @param {object} userDetails
 * @return {object}
 */
export async function sendOrder(order, userDetails) {
  const url = `${config.API_BASE}/api/v1/Order/Coffee`;
  try {
    const payload = {
      ...userDetails,
      items: order.list.map((item) => ({
        qty: Math.round(item.amount / 500),
        id: item.id,
      })),
    };
    const { data } = await api.post(url, payload);
    return data;
  } catch (error) {
    console.error(error);
    return { error: 'Failed to place the order' };
  }
}
