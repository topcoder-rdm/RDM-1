/**
 * A simple 404 error page.
 */

import React from 'react';

import { PageLayout, Link } from '@dr.pogodin/react-utils';

import './style.scss';

export default function Error404Page() {
  return (
    <PageLayout>
      <Link to="/">&lArr; Back to coffee list</Link>
      <h1>Error 404: Requested resource is not found.</h1>
    </PageLayout>
  );
}
