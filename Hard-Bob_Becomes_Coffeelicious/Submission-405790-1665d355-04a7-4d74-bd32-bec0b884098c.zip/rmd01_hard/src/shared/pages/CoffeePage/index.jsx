/**
 * Individual coffee offering page.
 */

import React from 'react';

import {
  Button,
  Link,
  PageLayout,
  PT,
  Throbber,
  useAsyncData,
  useGlobalState,
} from '@dr.pogodin/react-utils';

import Cart from 'components/Cart';

import { loadCoffeeSpecies } from 'services';

import './style.scss';

export default function CoffeePage({
  match,
}) {
  const { data } = useAsyncData('coffeeSpicies', loadCoffeeSpecies);
  const [order, setOrder] = useGlobalState('order', {});
  let content;
  if (!data) content = <Throbber />;
  else if (data.error) content = <div>{data.error}</div>;
  else {
    const coffee = data.find((it) => it.id === match.params.id);
    if (!coffee) content = <div>Unknown coffee ID</div>;
    else {
      const currentOrder = order[coffee.id] || { amount: 0 };
      content = (
        <div>
          <img alt="thumbnail" src={coffee.imageUrl} styleName="thumbnail" />
          <h1>{coffee.name}</h1>
          <p>${coffee.price} / 500g</p>
          <p>{coffee.description}</p>
          <p>
            <strong>In your current order:</strong>
            &zwnj; {currentOrder.amount}g
            {
              currentOrder.amount ? (
                <> (${(coffee.price * currentOrder.amount) / 500})</>
              ) : null
            }
          </p>
          <div styleName="buttons">
            <Button
              onClick={() => {
                setOrder({
                  ...order,
                  [coffee.id]: {
                    ...currentOrder,
                    amount: currentOrder.amount + 500,
                  },
                });
              }}
            >
              Add 500g
            </Button>
            {
              currentOrder.amount > 0 ? (
                <Button
                  onClick={() => {
                    setOrder({
                      ...order,
                      [coffee.id]: {
                        ...currentOrder,
                        amount: currentOrder.amount - 500,
                      },
                    });
                  }}
                >
                  Remove 500g
                </Button>
              ) : null
            }
          </div>
        </div>
      );
    }
  }
  return (
    <PageLayout>
      <div styleName="header">
        <Link to="/">
          &lArr; Other Coffee Types
        </Link>
        <Cart />
      </div>
      <div>
        {content}
      </div>
    </PageLayout>
  );
}

CoffeePage.propTypes = {
  match: PT.shape({
    params: PT.shape({
      id: PT.string.isRequired,
    }).isRequired,
  }).isRequired,
};
