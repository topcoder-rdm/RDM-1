/**
 * The landing (coffee list) page.
 */

import React from 'react';

import {
  Link,
  PageLayout,
  PT,
  Throbber,
  useAsyncData,
} from '@dr.pogodin/react-utils';

import Cart from 'components/Cart';

import { loadCoffeeSpecies } from 'services';

import imgHeader from 'assets/coffee-beans.jpg';

import './style.scss';

function CoffeeItem({
  id,
  name,
  thumbnail,
  price,
}) {
  return (
    <Link
      styleName="coffeeItem"
      to={`/coffee/${id}`}
    >
      <img alt="Thumbnail" styleName="coffeeThumbnail" src={thumbnail} />
      <div>
        <div styleName="coffeeName">{name}</div>
        <div>${price} / 500g</div>
      </div>
    </Link>
  );
}
CoffeeItem.propTypes = {
  id: PT.string.isRequired,
  name: PT.string.isRequired,
  thumbnail: PT.string.isRequired,
  price: PT.number.isRequired,
};

export default function Landing() {
  const { data } = useAsyncData('coffeeSpicies', loadCoffeeSpecies);
  let content;
  if (!data) content = <Throbber />;
  else if (data.error) content = <div>{data.error}</div>;
  else {
    content = data.map((item) => (
      <CoffeeItem
        id={item.id}
        key={item.id}
        name={item.name}
        thumbnail={item.imageUrl}
        price={item.price}
      />
    ));
  }
  return (
    <PageLayout>
      <div styleName="content">
        <div styleName="header">
          <img alt="Header" src={imgHeader} styleName="headerImage" />
          <Cart />
        </div>
        <h1>Coffee Order Time!</h1>
        <div styleName="mainContent">{content}</div>
      </div>
    </PageLayout>
  );
}
