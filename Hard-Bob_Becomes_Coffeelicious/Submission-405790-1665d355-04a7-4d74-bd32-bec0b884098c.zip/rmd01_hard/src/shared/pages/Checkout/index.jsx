/**
 * Order checkout page.
 */

import React from 'react';

import validator from 'validator';

import {
  _,
  Button,
  Input,
  Link,
  PageLayout,
  PT,
  Throbber,
  useAsyncData,
  useGlobalState,
} from '@dr.pogodin/react-utils';

import {
  calcOrder,
  loadCoffeeSpecies,
  sendOrder,
} from 'services';

import styles from './style.scss';

const RESULT = {
  FAILED: 'FAILED',
  PLACED: 'PLACED',
};

function Item({
  id,
  name,
  amount,
  price,
}) {
  const [order, setOrder] = useGlobalState('order', {});
  return (
    <tr>
      <td>{name}</td>
      <td styleName="center">{amount}g</td>
      <td styleName="center">${price.toFixed(2)}</td>
      <td>
        <Button
          onClick={() => {
            setOrder(_.omit(order, id));
          }}
        >
          Remove
        </Button>
      </td>
    </tr>
  );
}

Item.propTypes = {
  id: PT.string.isRequired,
  name: PT.string.isRequired,
  amount: PT.string.isRequired,
  price: PT.number.isRequired,
};

export default function Checkout() {
  const { data } = useAsyncData('coffeeSpicies', loadCoffeeSpecies);
  const [order, setOrder] = useGlobalState('order', {});
  const [userDetails, setUserDetails] = useGlobalState('userDetails', {});

  const [invalidEmail, setInvalidEmail] = React.useState(false);

  const [result, setResult] = React.useState();

  let content;
  if (!data) content = <Throbber />;
  else if (data.error) content = <div>{data.error}</div>;
  else if (result === RESULT.PLACED) {
    content = <div>Your order was successfully placed</div>;
  } else {
    const oo = calcOrder(order, data);
    if (!oo.list.length) {
      content = <p>Your order is empty</p>;
    } else {
      oo.list.sort((a, b) => a.name.localeCompare(b.name));
      content = (
        <div>
          <h3>Your Order</h3>
          <table styleName="table">
            <thead>
              <tr>
                <th>Product</th>
                <th>Amount</th>
                <th>Price</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {
                oo.list.map((item) => (
                  <Item
                    key={item.id}
                    {...item} // eslint-disable-line react/jsx-props-no-spreading
                  />
                ))
              }
            </tbody>
          </table>
          <div styleName="total">
            <strong>Total:</strong> ${oo.price.toFixed(2)}
          </div>
          <h3>Your Details</h3>
          {
            result === RESULT.FAILED ? (
              <div styleName="invalid">
                Failed to place your order, please try again.
              </div>
            ) : null
          }
          <div styleName="userDetails">
            <div>
              <Input
                label="Name"
                onChange={(e) => setUserDetails({
                  ...userDetails,
                  name: e.target.value,
                })}
                value={userDetails.name || ''}
              />
            </div>
            <div>
              <Input
                label="Address"
                onChange={(e) => setUserDetails({
                  ...userDetails,
                  address: e.target.value,
                })}
                value={userDetails.address || ''}
              />
            </div>
            <div className={invalidEmail ? styles.invalidFrame : undefined}>
              <Input
                label="Email"
                onChange={(e) => setUserDetails({
                  ...userDetails,
                  email: e.target.value,
                })}
                value={userDetails.email || ''}
                type="email"
              />
            </div>
            {
              invalidEmail ? (
                <div styleName="invalid">
                  Invalid email
                </div>
              ) : null
            }
            <div>
              <Input
                label="Phone Number"
                onChange={(e) => setUserDetails({
                  ...userDetails,
                  phoneNo: e.target.value,
                })}
                value={userDetails.phoneNo || ''}
              />
            </div>
            <div>
              <Button
                disabled={
                  !userDetails.name
                    || !userDetails.address
                    || !userDetails.email
                    || !userDetails.phoneNo
                }
                onClick={async () => {
                  const isEmailValid = validator.isEmail(userDetails.email);
                  setInvalidEmail(!isEmailValid);
                  if (isEmailValid) {
                    const res = await sendOrder(oo, userDetails);
                    if (res.error) {
                      setResult(RESULT.FAILED);
                    } else {
                      setOrder({});
                      setResult(RESULT.PLACED);
                    }
                  }
                }}
              >
                Submit
              </Button>
            </div>
          </div>
        </div>
      );
    }
  }

  return (
    <PageLayout>
      <Link to="/">&lArr; Back to the coffee list</Link>
      <h1>Checkout</h1>
      {content}
    </PageLayout>
  );
}
