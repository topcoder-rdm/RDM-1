# TC RDM #1 - HARD

To run with Docker:
```
$ docker-compose up -d
```
The web app is exposed at port 3000.

To install, test, and run in development mode:
```bash
$ npm install
$ npm run dev
```

To install, and run in production mode:
```bash
$ npm install
$ npm run build
$ npm start
```
