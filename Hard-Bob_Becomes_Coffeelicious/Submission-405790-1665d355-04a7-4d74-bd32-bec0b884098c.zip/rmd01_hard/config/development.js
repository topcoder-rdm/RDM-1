/**
 * Development-specific configuration.
 */

module.exports = {};
