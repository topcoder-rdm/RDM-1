/**
 * Right place for any custom Webpack config, common for all environments.
 */

module.exports = {};
