/**
 * Common configuration.
 */

module.exports = {
  API_BASE: 'https://alicecoffeeshop.devtesting.live',

  /* Base URL for example docs (hosted inside @dr.pogodin/react-utils repo). */
  DOCS_BASE: 'https://github.com/birdofpreyru/react-utils/blob/master/docs',
};
