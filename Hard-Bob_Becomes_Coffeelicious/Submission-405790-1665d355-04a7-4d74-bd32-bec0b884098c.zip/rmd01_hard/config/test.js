/**
 * Test-specific configuration.
 */

module.exports = {};
