const config = require('@dr.pogodin/react-utils/config/jest/default');

module.exports = config;
