(function() {

    function showError(msg) {
        let error = document.getElementById("error");
        if (msg === undefined) {
            msg = "Error encountered. Please check back later.";
        }
        error.innerText = msg;
        error.style.display = "block";
    }

    // "Animate" the loading bar
    let isLoading = true;
    function animateLoading() {
        if (!isLoading) {
            return;
        }
        document.getElementById("loading").style.display = "block";
        let progress = document.getElementById("progress");
        if (progress.innerText === "...") {
            progress.innerText = "";
        } else {
            progress.innerText += ".";
        }
        setTimeout(animateLoading, 500);
    }
    setTimeout(animateLoading, 500);

    // Store coffee data
    let coffeeDataById;

    // Cart related - stored in browser local storage
    function addToCart(id, unit) {
        let cartStr = window.localStorage.getItem("coffeeCart");
        if (!cartStr) {
            cartStr = "{}";
        }
        let cart = JSON.parse(cartStr);
        if (typeof cart[id] === "undefined") {
            cart[id] = 0;
        }
        cart[id] += unit;
        window.localStorage.setItem("coffeeCart", JSON.stringify(cart));
    }
    function getCart() {
        let cartStr = window.localStorage.getItem("coffeeCart");
        if (!cartStr) {
            cartStr = "{}";
        }
        let cart = JSON.parse(cartStr);
        return cart;
    }
    function clearCart() {
        window.localStorage.clear();
    }
    function updateCartDisplay() {
        let cart = getCart();

        let totalItemCount = 0;
        let totalPrice = 0;
        let cartDisplay = "<hr/>";
        let coffeeId;
        for (coffeeId in cart) {
            let coffeeData = coffeeDataById[coffeeId];
            let unit = cart[coffeeId];
            totalItemCount++;
            totalPrice += unit * (100*coffeeData.price);
            cartDisplay += coffeeData.name + " - " + (unit*500) + "gms" + " - " + "USD " + (unit*(100*coffeeData.price)/100);
            cartDisplay += "<br/>";
        }
        cartDisplay += "<hr/>";
        cartDisplay += "Total - " + "USD " + (totalPrice/100);

        document.getElementById("cart-summary-number").innerText = totalItemCount;
        document.getElementById("cart-detail").innerHTML = cartDisplay;

        if (totalItemCount > 0) {
            document.getElementById("goto-checkout").style.display = "block";
        } else {
            document.getElementById("goto-checkout").style.display = "none";
        }
    }

    // Summit order
    document.getElementById("checkout-form").addEventListener("submit", function(evt) {

        let formData = new FormData(evt.target);
        let postData = {};
        postData["name"] = formData.get("name");
        postData["address"] = formData.get("address");
        postData["email"] = formData.get("email");
        postData["phoneNo"] = formData.get("phone");
        postData["items"] = [];

        let cart = getCart();
        let coffeeId;
        for (coffeeId in cart) {
            postData["items"].push({
                "qty": cart[coffeeId],
                "id": coffeeId
            });
        }
        
        let xhr = new XMLHttpRequest();
        xhr.addEventListener("load", function() {
            if (xhr.status !== 200) {
                showError();
                return;
            }
            document.getElementById("checkout").style.display = "none";
            clearCart();
            updateCartDisplay();
            document.getElementById("coffee-cart").style.display = "none";
            document.getElementById("thankyou").style.display = "block";
        });
        xhr.open("POST", "https://alicecoffeeshop.devtesting.live/api/v1/Order/Coffee");
        xhr.setRequestHeader("Content-Type", "application/json");
        xhr.send(JSON.stringify(postData));
        evt.preventDefault();
    });

    // Setup click handlers
    document.getElementById("close").addEventListener("click", function() {
        document.getElementById("coffee-detail").style.display = "none";
        document.getElementById("greyout").style.display = "none";
    });
    document.getElementById("greyout").addEventListener("click", function() {
        document.getElementById("coffee-detail").style.display = "none";
        document.getElementById("greyout").style.display = "none";
    });
    document.getElementById("add-cart").addEventListener("click", function() {
        let coffeeId = document.getElementById("coffee-detail").dataset.id;
        let count = parseInt(document.getElementById("coffee-unit").value);
        addToCart(coffeeId, count);
        updateCartDisplay();
    });
    document.getElementById("goto-checkout").addEventListener("click", function() {
        document.getElementById("coffee-list").style.display = "none";
        document.getElementById("checkout").style.display = "block";
    });

    function setup(coffeeList) {
        let i;
        coffeeDataById = {};
        for (i = 0; i < coffeeList.length; i++) {
            coffeeDataById[coffeeList[i].id] = coffeeList[i];
        }
        function displayCoffeeDetail(evt) {
            let detail = document.getElementById("coffee-detail");
            if (detail.style.display === "block") {
                return;
            }
            let target = evt.target;
            while (!target.classList.contains("coffee-item")) {
                target = target.parentElement;
            }
            let id = target.dataset.id;
            let coffeeData = coffeeDataById[id];
            detail.dataset.id = id;
            detail.querySelector(".coffee-name").innerText = coffeeData.name;
            detail.querySelector(".coffee-image").src = coffeeData.imageUrl;
            detail.querySelector(".coffee-description").innerText = coffeeData.description;
            detail.querySelector(".coffee-price-number").innerText = coffeeData.price;
            detail.style.display = "block";
            document.getElementById("greyout").style.display = "block";
        }
        for (i = 0; i < coffeeList.length; i++) {
            let coffee = document.getElementById("coffee-template").cloneNode(true);
            coffee.id = "";
            coffee.style.display = "block";
            coffee.dataset.id = coffeeList[i].id;
            coffee.querySelector(".coffee-name").innerText = coffeeList[i].name;
            coffee.querySelector(".coffee-image").src = coffeeList[i].imageUrl;
            coffee.querySelector(".coffee-price-number").innerText = coffeeList[i].price;
            coffee.addEventListener("click", displayCoffeeDetail, false);
            document.getElementById("coffee-list").appendChild(coffee);
        }
    }

    // Load coffee data
    let xhr = new XMLHttpRequest();
    xhr.addEventListener("load", function() {
        isLoading = false;
        document.getElementById("loading").style.display = "none";
        if (xhr.status !== 200) {
            showError();
            return;
        }
        let coffeeList = JSON.parse(xhr.response);
        if (coffeeList.length === 0) {
            showError("No product available at the moment. Please check back later.");
            return;
        }
        setup(coffeeList);
        updateCartDisplay();
    });
    xhr.open("GET", "https://alicecoffeeshop.devtesting.live/api/v1/Coffee/Species");
    xhr.send();
})();

