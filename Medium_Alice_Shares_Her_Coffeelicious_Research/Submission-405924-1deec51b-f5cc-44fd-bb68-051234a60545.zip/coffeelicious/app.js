var express = require('express');
var logger = require('morgan');

var indexRouter = require('./routes/index');
var coffeeRouter = require('./routes/coffee');
var apiDocRouter = require('./routes/apiDocs');

var app = express();


app.use(logger('dev'));
app.use(express.json());
app.use('/', indexRouter);
app.use('/coffee', coffeeRouter);
app.use('/api-docs', apiDocRouter)

module.exports = app;
