const fs = require('fs');

const ROOT_DIR = 'assets/e-commerce/coffee/';

// Display list of all species.
exports.speciesList = (req, res) => {
    try {
        var species = [];
        fs.readdir(ROOT_DIR, (error, files) => {
            //handling error
            if (error) {
                return res.status(400).json({ error: error.message });
            } 
            //listing all files using forEach
            files.forEach(file => {
                species.push({'species' : file})
            })
            return res.status(200).json(species);
        })
    } catch (err) {
        return res.status(400).json({ error: err.message });
    }
  }

  //display species data
  exports.speciesData  = (req, res) => {
    try {
        const species= req.params.id;
        var data = {};
        if(!fs.existsSync(ROOT_DIR+species)) {
            return res.status(404).json({ error: `${species} is not a species` });
        }
        // read price
        try {
            var price = fs.readFileSync(ROOT_DIR+species+"/about/price.txt", 'utf8')
            data["price"] = price;
        } catch(error) {
            if (error.code !== 'ENOENT') {
                throw err;
            }
        }
        // read text
        try {
            var desc = fs.readFileSync(ROOT_DIR+species+"/about/desc.txt", 'utf8')
            data["desc"] = desc;
        } catch(error) {
            if (error.code !== 'ENOENT') {
                throw err;
            }
        }
        // get all images
        var images = [];
        fs.readdir(ROOT_DIR+species+'/images', (error, files) => {
            //handling error
            if (error && error.code !== 'ENOENT') {
                return res.status(400).json({ error: error.message });
            } 
            if(files) {
                files.forEach( file => {
                    images.push(file)
                })
                data["images"] = images;
            }
            console.log("exports.speciesData -> data", data)
            return res.status(200).json(data);
        })
    } catch (err) {
        return res.status(400).json({ error: err.message });
    }
  }