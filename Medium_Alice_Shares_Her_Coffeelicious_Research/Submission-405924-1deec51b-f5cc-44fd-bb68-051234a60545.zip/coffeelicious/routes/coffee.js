var express = require('express');
var coffeeController = require('../controllers/coffee');
var router = express.Router();

/* GET users listing. */
router.get('/', coffeeController.speciesList);
router.get('/:id',coffeeController.speciesData);

module.exports = router;
