1. Data folder must be named 'e-commerce' and placed at project root (same level as Dockerfile). Alternatively, update docker-compose.yml, replacing "./e-commerce" with path to your data folder.
2. Start docker container: `docker-compose up -d`
3. Verify API:
    1. Get all: 
        - localhost:5000/
        - http://prntscr.com/uw6l0t
    2. Get single:
        - localhost:5000/arabica
        - http://prntscr.com/uw6mem
    3. Get image:
        - localhost:5000/image/arabica/30sdfknl09123-arabica-23ij09d67as5123.png
        - http://prntscr.com/uw6ud6