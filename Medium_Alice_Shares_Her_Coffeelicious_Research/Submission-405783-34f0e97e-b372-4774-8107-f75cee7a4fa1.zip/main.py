import os
from pathlib import Path
from flask import Flask, send_file
from flask_restful import Resource, Api
from collections import defaultdict

data = defaultdict(lambda: {'description': None, 'price': None, 'images': []})
images = {}
app = Flask(__name__)
api = Api(app)

class SpeciesList(Resource):
    def get(self):
        return data

class Specie(Resource):
    def get(self, name):
        if name in data:
            return data[name]
        else:
            return None, 404

class Image(Resource):
    def get(self, path):
        if path in images:
            return send_file(images[path])
        else:
            return None, 404 

# Get file paths within a folder
def get_paths(folderPath):
    for dirpath, _, filenames in os.walk(folderPath):
        for name in filenames:
            yield os.path.join(dirpath, name)

def load_data(folderPath):
    files = [Path(x) for x in get_paths(folderPath)]

    for file in files:
        for idx, part in enumerate(file.parts):
            if part.lower() == 'about':
                species = file.parts[idx-1]
                nextPart = file.parts[idx+1].lower()

                if nextPart.startswith('price'):
                    data[species]['price'] = float(file.read_text())
                else:
                    data[species]['description'] = file.read_text()
                
                break
            elif part.lower() == 'images':
                species = file.parts[idx-1]
                publicPath = species + '/' + file.name
                data[species]['images'].append(publicPath)
                images[publicPath] = file.as_posix();
                break


if __name__ == "__main__":
    # Init data and API
    load_data('./data-folder')
    api.add_resource(SpeciesList, '/')
    api.add_resource(Specie, '/<name>')
    api.add_resource(Image, '/image/<path:path>')
    app.run(host='0.0.0.0', port=5000, debug=True)