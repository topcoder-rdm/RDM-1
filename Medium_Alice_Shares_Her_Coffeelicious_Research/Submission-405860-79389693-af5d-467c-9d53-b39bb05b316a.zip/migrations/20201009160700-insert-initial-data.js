const fs = require('fs');
const path = require('path');
const _ = require('lodash');
const config = require('config');

var dbm;
var type;
var seed;

/**
  * We receive the dbmigrate dependency from dbmigrate initially.
  * This enables us to not have to rely on NODE_PATH.
  */
exports.setup = function(options, seedLink) {
  dbm = options.dbmigrate;
  type = dbm.dataType;
  seed = seedLink;
};

const getData = () => {
  const data = [];

  const dataDir = path.join(__dirname, '../data/coffee')
  const baseServerUrl = `${config.get('server.proto')}://${config.get('server.host')}:${config.get('server.port')}`;
  
  const species = fs.readdirSync(dataDir);
  _.each(species, coffee => {
    // ignore hidden files
    if (coffee.startsWith('.')) return;
    const imgs = fs.readdirSync(path.join(dataDir, coffee, 'images'));
    data.push({
      name: coffee,
      description: fs.readFileSync(path.join(dataDir, coffee, 'about/desc.txt')).toString(),
      price: parseFloat(fs.readFileSync(path.join(dataDir, coffee, 'about/price.txt')).toString()),
      images: imgs.map(img => `${baseServerUrl}/images/${img}`),
    });
  });
  return data;
};

exports.up = function(db) {
  const data = getData();
  db.insert('coffee_species', data);
  return null;
};

exports.down = function(db) {
  return null;
};

exports._meta = {
  "version": 1
};
