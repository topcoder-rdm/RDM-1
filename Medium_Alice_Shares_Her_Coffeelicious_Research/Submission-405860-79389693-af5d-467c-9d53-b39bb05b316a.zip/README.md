# Alice Shares Her Coffeelicious Research - RDM 1 - Medium - 500 Points

## Prerequisites
- Node v12+
- Docker Desktop

## How to run?
- Install dependencies:
```bash
  npm install
```
- Run the following command with correct data directory:
```bash
  npm run setup -- --src <ABSOLUTE-PATH-TO-SRC-DIR>
```
For, example:
```
  npm run setup -- --src /Users/deepak/Downloads/e-commerce
```

## Configuration
Use file `config/docker.js` to configure following:
  - Database Config
    - driver
    - host
    - port
    - database
  - Server Config:
    - protocol
    - host
    - port


## Verification
- Use postman collection in the `docs/` folder to verify the endpoints.
- To get list of all speicies, trigger the following GET request:
```
  curl -XGET http://localhost:4000/species
```
- To get details of a specific species, trigger the following GET request:
```
  curl -XGET http://localhost:4000/species/:name
```
