module.exports = {
  db: {
    host: 'db',
  }
};
