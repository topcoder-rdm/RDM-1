module.exports = {
  db: {
    driver: 'mongodb',
    host: 'localhost',
    port: 27017,
    database: 'alice'
  },
  server: {
    proto: 'http',
    host: 'localhost',
    port: 4000,
  },
};
