const mongoose = require('mongoose');

const schema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  description: {
    type: String,
    required: true,
  },
  price: {
    type: Number,
    required: true,
  },
  images: [String],
}, {
  collection: 'coffee_species'
});


module.exports = mongoose.model('CoffeeType', schema);
