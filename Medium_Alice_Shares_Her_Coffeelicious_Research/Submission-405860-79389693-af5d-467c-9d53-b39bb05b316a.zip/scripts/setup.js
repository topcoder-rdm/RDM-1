/**
 * Copies data directory to root directory
 */
const cliArgs = require('command-line-args');
const fs = require('fs-extra');
const path = require('path');
const _ = require('lodash');
const rimraf = require('rimraf')

const opts = cliArgs([{ name: 'src', type: String, required: true }]);

if (!opts.src) {
  console.error(`
    Please provide source directory path in argument "src"
    Usage : npm run setup -- --src <ABSOLUTE_PATH_TO_DIRECTORY>
  `)
  process.exit(1);
}

const dataBasePath = path.join(__dirname, '../data');
const publicPath = path.join(__dirname, '../public');

rimraf.sync(dataBasePath);

fs.mkdirp(dataBasePath);
fs.copySync(opts.src, dataBasePath);

fs.mkdirp(publicPath);
const dataDir = path.join(__dirname, '../data/coffee')
const species = fs.readdirSync(dataDir);

_.each(species, coffee => {
  // ignore hidden files
  if (coffee.startsWith('.')) return;
  const imgDirPath = path.join(dataDir, coffee, 'images');
  const imgs = fs.readdirSync(imgDirPath);
  _.each(imgs, img => {
    const imgPath = path.join(imgDirPath, img);
    const newImgPath = path.join(publicPath, img);
    fs.copyFileSync(imgPath, newImgPath);
  })
})
