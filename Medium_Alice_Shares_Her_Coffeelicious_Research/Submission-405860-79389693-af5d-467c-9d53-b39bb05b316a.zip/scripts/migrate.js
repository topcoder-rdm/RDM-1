const _ = require('lodash');
const commandLineArgs = require('command-line-args')
const DBMigrate = require('db-migrate');
const config = require('config');

const dbm = DBMigrate.getInstance(true, {
  config: {
    default: 'mongo',
    mongo: config.get('db'),
  }
});

const options = [
  { name: 'up', type: Number },
  { name: 'down', type: Number },
  { name: 'create', type: String },
];

const cliArgs = commandLineArgs(options);

if (_.has(cliArgs, 'up')) {
  dbm.up(cliArgs.up);
}

else if (_.has(cliArgs, 'down')) {
  dbm.down(cliArgs.down).then(function() {
    console.log('Successfully migrated down all migrations!');
  });
}

else if (cliArgs.create) {
  dbm.create(cliArgs.create).then(function() {
    console.log(`Created a migration file: ${cliArgs.create}`);
  });
}

else {
  console.error('Please enter a valid argument');
  process.exit(1);
}
