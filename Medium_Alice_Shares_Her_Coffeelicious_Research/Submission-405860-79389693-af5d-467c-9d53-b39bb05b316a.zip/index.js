const express = require('express');
const helmet = require('helmet');
const config = require('config');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const DBMigrate = require('db-migrate');
const CoffeeType = require('./models/CoffeeType');

const app = express();
app.use(helmet());
app.use(bodyParser.json());

app.use('/images', express.static('public'));

const d = config.get('db');
const dbUrl = `${d.driver}://${d.host}:${d.port}/${d.database}`;
mongoose.connect(dbUrl);

app.get('/species', async (req, res) => {
  const docs = await CoffeeType.find().lean();
  const total = await CoffeeType.count();
  res.json({
    docs, total,
  });
});

app.get('/species/:name', async (req, res) => {
  const q = {};
  if (req.params.name) {
    q.name = req.params.name;
  } else {
    res.status(400).json({
      message: 'Valid coffee species name is required'
    });
    return;
  }
  const doc = await CoffeeType.findOne(q);
  if (!doc) {
    res.status(404).json({
      message: 'No coffee species found with given name',
    });
    return;
  }
  res.json(doc);
});

app.listen(config.get('server.port'), () => {
  console.log('Serving at port ' + config.get('server.port'));
  setTimeout(() => {
    const dbm = DBMigrate.getInstance(true, {
      config: {
        default: 'mongo',
        mongo: config.get('db'),
      }
    });
    dbm.up();
  }, 2000);
});
