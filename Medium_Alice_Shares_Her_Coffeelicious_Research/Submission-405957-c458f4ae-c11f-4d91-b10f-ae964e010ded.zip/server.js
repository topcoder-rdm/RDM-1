const fs = require("fs");
const express = require("express");
const app = express();
const port = 4000;
const dataPath = "./data/";
const speciesInfo = [];

// get species info
try {
  const species = fs
    .readdirSync(dataPath + "e-commerce/coffee/")
    .filter((item) => !/^[\w\s]+\.[A-Za-z]+$/.test(item));

  species.forEach((specie) => {
    const filePath = dataPath + "e-commerce/coffee/" + specie + "/about/";
    const description = fs.readFileSync(filePath + "desc.txt", "utf-8");
    const price = fs.readFileSync(filePath + "price.txt", "utf-8");

    speciesInfo.push({
      name: specie,
      description,
      price,
    });
  });
} catch (error) {
  console.log(error);
}

// build up server for api requests
app.get("/", (req, res) => {
  return res.send(speciesInfo.map((s) => s.name));
});

app.get("/:specie", (req, res) => {
  const { specie } = req.params;
  console.log(specie);
  const info = speciesInfo.filter((s) => s.name === specie);
  if (info.length === 0) {
    return res.send("No such specie.");
  } else {
    return res.send(info[0]);
  }
});

app.listen(port, () => {
  console.log(`API Server listening at http://localhost:${port}`);
});
