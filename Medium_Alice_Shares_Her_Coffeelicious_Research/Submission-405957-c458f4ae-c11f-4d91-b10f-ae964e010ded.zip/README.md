# Alice Share Her Coffeelicious Research

[Problem Detail](https://www.topcoder.com/challenges/3b951a78-0780-4c37-952b-098c04580665)

## Please Note

- Pre-request to run the solution -
  - Install Node.js Latest version (V10 or above).
  - Install node packages at the root folder.
  ```bash
  $ yarn install
  ```
- To run api server

```bash
$ yarn start
```

- To get all species info, access `http://localhost:4000/`.
- To get specific specie info, put specie name in request url, such as:
  - [http://localhost:4000/arabica](http://localhost:4000/arabica)
  - [http://localhost:4000/liberica](http://localhost:4000/liberica)
  - [http://localhost:4000/robusta](http://localhost:4000/robusta)
