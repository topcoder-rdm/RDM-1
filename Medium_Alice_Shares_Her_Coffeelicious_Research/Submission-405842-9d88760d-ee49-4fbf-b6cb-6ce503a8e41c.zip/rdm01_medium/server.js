/**
 * Setup of ExpressJS app.
 */

const fs = require('fs');
const { v4: uuid } = require('uuid');
const config = require('config');
const bodyParser = require('body-parser');
const { StatusCodes: CODE } = require('http-status-codes');
const express = require('express');
const loggerMiddleware = require('morgan');
const stream = require('stream');

const app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

loggerMiddleware.token('ip', (req) => req.clientIp);

/* Loads data index into memory. */
const files = {};
const data = [];
fs.readdirSync(`${__dirname}/data/e-commerce/coffee`)
  .forEach((name) => {
    const meta = { name, images: [] };
    const imgFolder = `${__dirname}/data/e-commerce/coffee/${name}/images`;
    fs.readdirSync(imgFolder).forEach((img) => {
      const id = uuid();
      meta.images.push(`/images/${id}`);
      files[id] = `${imgFolder}/${img}`;
    });
    const aboutFolder = `${__dirname}/data/e-commerce/coffee/${name}/about`;
    meta.desc = fs.readFileSync(`${aboutFolder}/desc.txt`, 'utf8');
    meta.price = parseFloat(
      fs.readFileSync(`${aboutFolder}/price.txt`, 'utf8')
    );
    data.push(meta);
  });

/**
 * Creates a new Error with the specified message and HTTP error code.
 * @param {String} msg Error message.
 * @param {Number} statusCode Optional. HTTP error code. Defaults to 500.
 * @return {Error}
 */
function newError(msg, statusCode = CODE.INTERNAL_SERVER_ERROR) {
  const error = new Error(msg);
  error.statusCode = statusCode;
  return error;
}

/**
 * Throws an error with the specified message and HTTP error code.
 * @param {String} msg Error message.
 * @param {Number} statusCode Optional. HTTP error code. Defaults to 500.
 * @throws {Error} HTTP error.
 */
function fail(msg, statusCode = CODE.INTERNAL_SERVER_ERROR) {
  const error = newError(msg, statusCode);
  console.error(error);
  throw error;
}

app.use(loggerMiddleware(':ip > :status :method :url :response-time ms :res[content-length] :referrer :user-agent', {
  stream: new stream.Writable({
    decodeStrings: false,
    write: (chunk, encoding, cb) => {
      console.log(chunk);
      cb();
    },
  }),
}));

/* Mount all routers in this section. */

/**
 * Simplest possible auth check
 * @param {object} req
 * @param {object} res
 * @param {function} next
 */
function auth(req, res, next) {
  let { authorization } = req.headers;
  if (authorization) authorization = authorization.match('Key (.*)');
  if (authorization) authorization = authorization[1];
  authorization = config.API_KEYS.includes(authorization);
  if (!authorization) fail('Unathorized', CODE.UNAUTHORIZED);
  next();
}

app.get('/', auth, (req, res, next) => {
  res.json(data.map((item) => item.name));
});

app.get('/details/:id', auth, (req, res, next) => {
  const details = data.find((item) => item.name === req.params.id);
  if (!details) fail('Not found', CODE.NOT_FOUND);
  res.json(details);
});

app.get('/images/:id', auth, (req, res, next) => {
  const p = files[req.params.id];
  if (p) res.sendFile(p);
  else fail('Not found', CODE.NOT_FOUND);
});

/* Catches 404 and forwards it to error handler. */
app.use((req, res, next) => {
  const err = new Error('Not Found');
  err.statusCode = 404;
  next(err);
});

/* Error handler. */
app.use((err, req, res, next) => { // eslint-disable-line no-unused-vars
  /* Do not give away any error details in prod. */
  if (process.env.NODE_ENV === 'production') {
    res.sendStatus(err.statusCode || CODE.INTERNAL_SERVER_ERROR);
  } else {
    res.status(err.statusCode || CODE.INTERNAL_SERVER_ERROR)
      .send(err.message || 'Internal Server Error');
  }
});

module.exports = app;
