# TC RDM #1 - MEDIUM

As per specs, it can be launched like (starts at the port 3000):

```
$ docker-compose up -d
```

I have included Postman collection into `/docs` folder. Basically, there are
three endpoints:
- `GET /` - returns the list of valid coffee specie names.
- `GET /details/{specie}` - returns information about the specified species.
- `GET /images/{id}` - returns image with the ID taken from the response of
  previous endpoint.

As specs mention "Alice decides to share what she has collected with the outside
world. But she doesn't want to share it without knowing about them. We need
to help Alice out with an API that helps her share data in a secure and best
possible way." I added a very simple auth mechanics: API only accepts requests
including `Authorization` header with `Key KEY_VALUE` value. The list of
accepted `KEY_VALUE`s is configurable in `/config/default.json`.
