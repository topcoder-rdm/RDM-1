const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();

const baseDir = path.join('e-commerce', 'coffee');

function getSpeciesData(species) {
  const description = fs.readFileSync(path.join(baseDir, species, 'about', 'desc.txt'), 'utf-8');
  const price = fs.readFileSync(path.join(baseDir, species, 'about', 'price.txt'), 'utf-8');
  const images = fs.readdirSync(path.join(baseDir, species, 'images')).map(image => `/${species}/images/${image}`);
  return {
    name: species,
    description,
    price,
    images
  };
}

app.get('/species', (req, res) => {
  const allSpecies = fs.readdirSync(baseDir);
  const data = allSpecies.map(species => getSpeciesData(species));
  res.json(data);
});

app.get('/species/:species', (req, res) => {
  const { species } = req.params;
  res.json(getSpeciesData(species));
});

app.get(`/:species/images/:image`, (req, res) => {
  const { species, image } = req.params;
  const imgPath = path.join(baseDir, species, 'images', image);
  res.setHeader('Content-Type', 'image/png');
  res.send(fs.readFileSync(imgPath));
});

const PORT = 5000;

app.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
