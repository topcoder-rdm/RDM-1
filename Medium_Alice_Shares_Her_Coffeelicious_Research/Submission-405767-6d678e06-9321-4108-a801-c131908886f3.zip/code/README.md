## Installation

`npm i`

## Running

`npm start`

## Usage

### GET All Species

`http://localhost:5000/species`

### GET a spcies details

`http://localhost:5000/species/{species_name}`
