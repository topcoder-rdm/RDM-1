# Usage
```
$ python3 rearange.py -path {PATH}
```

# Example
```
$ tree
.
├── data
│   ├── 0alkdjoi-liberica-09xifbdsihlg312.png
│   ├── 30sdfknl09123-arabica-23ij09d67as5123.png
│   ├── Arabica.txt
│   ├── Liberica.txt
│   ├── Robusta.txt
│   └── coffee-robusta-5ab4c8bee09125.7230548615217973109198.png
└── rearange.py

$ python3 rearange.py --help
usage: rearange.py [-h] -path PATH [--silent]

rearange image files and txt files.

optional arguments:
  -h, --help    show this help message and exit
  -path PATH    path to the directory which contains the descriptions and images.
  --silent, -s  enable silent mode

$ python3 rearange.py -path data --silent

$ tree
.
├── data
│   └── e-commerce
│       └── coffee
│           ├── arabica
│           │   ├── about
│           │   │   └── desc.txt
│           │   └── images
│           │       └── 30sdfknl09123-arabica-23ij09d67as5123.png
│           ├── liberica
│           │   ├── about
│           │   │   └── desc.txt
│           │   └── images
│           │       └── 0alkdjoi-liberica-09xifbdsihlg312.png
│           └── robusta
│               ├── about
│               │   └── desc.txt
│               └── images
│                   └── coffee-robusta-5ab4c8bee09125.7230548615217973109198.png
└── rearange.py
```

# Checked Environment
* Ubuntu 20.04 LTS
    * Python 3.8.2
* Windows 10
    * Python 3.8.6

