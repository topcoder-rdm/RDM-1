import argparse
import logging
import os
import re

desc_file_dest = 'e-commerce/coffee/{species}/about/desc.txt'
img_file_dest = 'e-commerce/coffee/{species}/images/{img}'
# *-{spieces}-*.png
img_file_pattern = re.compile(r'[^\-]+\-([^\-]+)\-[^\-]+\.png')

logging.basicConfig(format='%(levelname)s:%(message)s', level=logging.WARNING)
logger = logging.getLogger('rearange_log')


def rearange(target_dir: str):
    """
    move description text files to
        '{target_dir}/e-commerce/coffee/{species}/about/desc.txt'
    and image files to
        '{target_dir}/e-commerce/coffee/{species}/images/{img}'

    Args:
        target_dir: str
            path to the target directory which contains
            the descriptions and images.
    """

    # get file list
    try:
        entries = os.scandir(target_dir)
    except OSError as e:
        logger.error(e)
        return
    files = list(filter(lambda x: x.is_file(), entries))
    descriptions = filter(
        lambda x: os.path.splitext(x.path)[1] == '.txt', files)
    images = filter(
        lambda x: os.path.splitext(x.path)[1] == '.png', files)

    # move txt files
    for src in descriptions:
        spieces = os.path.splitext(os.path.basename(src.name))[0]
        spieces = spieces.lower()
        try:
            dst = desc_file_dest.format(species=spieces)
            dst = os.path.join(target_dir, dst)
            os.renames(src.path, dst)
            logger.info(f'moved description file.\n\t$src={src.path}\n\t$dst={dst}')

        except OSError as e:
            logger.warning(e)

    # move image files
    for src in images:
        name = os.path.basename(src.name)
        match = img_file_pattern.fullmatch(name)
        if match:
            spieces = match[1].lower()
        else:
            continue
        try:
            dst = img_file_dest.format(species=spieces, img=name)
            dst = os.path.join(target_dir, dst)
            os.renames(src.path, dst)
            logger.info(f'moved image file.\n\t$src={src.path}\n\t$dst={dst}')

        except OSError as e:
            logger.warning(e)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        description='rearange image files and txt files.')
    parser.add_argument('-path',
                        help='path to the directory which contains ' +
                             'the descriptions and images. ',
                        required=True)
    parser.add_argument('--silent', '-s',
                        action='store_true',
                        help='enable silent mode')
    args = parser.parse_args()

    if args.silent is False:
        logger.setLevel('DEBUG')
    rearange(args.path)
