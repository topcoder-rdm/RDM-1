import shutil
import os

def main():
    path = input()
    for file in os.listdir(path):
        if file.find(".txt") != -1:
            name = file[:-4]
            name = name.lower()

            src = os.path.join(path, file)
            new_path = path + "/" + name + "/about"
            
            # create the folder
            os.mkdir(path + "/" + name)
            os.mkdir(new_path)
            
            dst = os.path.join(new_path, "desc.txt")

            # move the txt file
            shutil.move(src, dst)

            # find the corresponding img file
            for img in os.listdir(path):
                if ((img.find(name) != -1) and (img.find(".png") != -1)):
                    src = os.path.join(path, img)

                    new_path = path + "/" + name + "/images"
                    os.mkdir(new_path)
                    
                    dst = os.path.join(new_path, img)

                    # move the img file
                    shutil.move(src, dst)


if __name__ == '__main__':
    main()