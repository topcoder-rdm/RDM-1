# RDM 01 - EASY

Either run with Node:

```bash
$ node index.js /path/to/set-1-1
```

or build and run with Docker:

```bash
$ docker build -t rdm01_easy .
$ docker run --rm -v /path/to/set-1-1:/workdir rmd01_easy /workdir
```
