const { match } = require('assert');
const fs = require('fs');
const path = require('path');

const inputFolder = path.resolve(process.argv[2]);

(async () => {
  const inputFiles = fs.readdirSync(inputFolder);
  inputFiles.forEach((name) => {
    const matchTxt = name.match(/(\w*)\.txt/);
    if (matchTxt) {
      const outFolder = `${inputFolder}/e-commerce/coffee/${
        matchTxt[1].toLowerCase()}/about`;
      fs.mkdirSync(outFolder, { recursive: true });
      fs.renameSync(`${inputFolder}/${name}`, `${outFolder}/dest.txt`);
    }
    const matchPng = name.match(/.*-(\w*)-.*\.png/);
    if (matchPng) {
      const outFolder = `${inputFolder}/e-commerce/coffee/${
        matchPng[1].toLowerCase()}/images`;
      fs.mkdirSync(outFolder, { recursive: true });
      fs.renameSync(`${inputFolder}/${name}`, `${outFolder}/${name}`);
    }
  });
})();
