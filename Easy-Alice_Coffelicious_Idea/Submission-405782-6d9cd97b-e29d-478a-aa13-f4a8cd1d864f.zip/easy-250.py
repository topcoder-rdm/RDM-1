import os
import glob
import click

def find_ext(dr, ext):
    return glob.glob(os.path.join(dr,"*.{}".format(ext)))

def create_root_path(download_path):
    root_path = os.path.join(download_path,'e-commerce'+str(os.sep)+'coffee')
    if not os.path.exists(root_path):
        os.makedirs(root_path)
    return root_path

def sort_desc_files(root_path,descs):
    coffee_names = []
    for desc in descs:
        coffee_name = desc.split(os.sep)[-1].split('.')[0]
        coffee_names.append(coffee_name)
        coffee_save_dir = os.path.join(root_path,coffee_name+str(os.sep)+'about')
        coffee_save_path = os.path.join(coffee_save_dir,coffee_name+'.txt')
        if not os.path.exists(coffee_save_dir):
            os.makedirs(coffee_save_dir)
        os.replace(desc, coffee_save_path)
    return coffee_names

def sort_image_files(root_path,images,coffee_names):
    for image in images:
        image_name = image.split(os.sep)[-1]
        for coffee_name in coffee_names:
            if coffee_name.lower() in image:
                coffee_save_dir = os.path.join(root_path,coffee_name+str(os.sep)+'images')
                coffee_save_path = os.path.join(coffee_save_dir,image_name)
                if not os.path.exists(coffee_save_dir):
                    os.makedirs(coffee_save_dir)
                os.replace(image, coffee_save_path)

@click.command()
@click.option('--dir_path', default=None, help="Download Dirrectory Path")
def cli(dir_path):
    try:
        if dir_path:
            print("Sorting Strated!")
            images = find_ext(dir_path,"png")
            descs = find_ext(dir_path,"txt")
            root_path = create_root_path(dir_path)
            coffee_names = sort_desc_files(root_path,descs)
            sort_image_files(root_path,images,coffee_names)
            print("Done!")
        else:
            print("Please enter directory path")
    except Exception as e:
        print("Error!")
        print(str(e))

if __name__ == '__main__':
    cli()