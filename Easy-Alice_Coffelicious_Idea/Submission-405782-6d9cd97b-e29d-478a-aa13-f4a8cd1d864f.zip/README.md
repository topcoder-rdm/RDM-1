# Alice's Coffeelicious Idea - RDM 1 - Easy - 250 Points
- The executable will take a parameter -path which has the path to the folder where Alice downloads all her stuff.

## Tech Stack
- [Anaconda Python3](https://www.anaconda.com/distribution/) or [Python3](https://www.python.org/downloads/)


## Product Dataset
You can download it from [Data](https://www.topcoder.com/direct/launch/downloadDocument?documentId=27532469), and extract.

## Installing and running locally
Run the following commands -
```CMD
conda create -n easy python==3.7 -y
conda activate easy
pip install click==7.1.1
python cli.py --dir_path=D:\topgear\RDM-1\250\set-1-1
```

## cli.py arguments:
- '--dir_path' - Download Dirrectory Path.


