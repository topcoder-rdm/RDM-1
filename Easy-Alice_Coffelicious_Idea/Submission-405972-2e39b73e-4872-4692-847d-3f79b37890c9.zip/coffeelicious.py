import os, shutil, re
import tkinter as tk
from tkinter import filedialog

# Pattern to filter .png file names
pattern = "-(.*?)-"

# Display window to select directory
root = tk.Tk()
root.withdraw()

# Get the selected directory path to sort
source = filedialog.askdirectory(title='Select directory to sort')

# Go through all the files in the selected directory
for file in os.listdir(source):
    # Extract coffee species and move text file to corresponding directory
    if file.endswith(".txt"):
        species = os.path.splitext(file)[0].lower()
        f1 = os.path.join(source, file)
        f2 = os.path.join(source, "e-commerce/coffee/", species, "about/")
        os.makedirs(os.path.dirname(f2), exist_ok=True)
        shutil.move(f1, f2)
    # Extract coffee species and move image file to corresponding directory 
    elif file.endswith(".png"):
        file_name = os.path.splitext(file)[0].lower()
        species = re.search(pattern, file_name).group(1)
        f1 = os.path.join(source, file)
        f2 = os.path.join(source, "e-commerce/coffee/", species, "images/")
        os.makedirs(os.path.dirname(f2), exist_ok=True)
        shutil.move(f1, f2)
    else:
        pass