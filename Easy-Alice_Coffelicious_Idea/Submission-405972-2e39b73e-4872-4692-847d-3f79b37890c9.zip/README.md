# Alice's Coffeelicious Idea - philippbara submission

I used python to write a simple script that sorts the directory according to the specification found [here](https://www.topcoder.com/challenges/49d91b1d-1b57-4088-9609-0ad107362b2e).

## Installation

In order to create the executable for all OS you can use [pyinstaller](https://www.pyinstaller.org/).
Simply install it through pip (or pip3) and run 
 
```
pyinstaller coffeelicious.py
```
to create the executable for another OS. 
The generated executable is located under **dist** directory. The script has been tested with on 
Ubuntu 18.04 and the corresponding executable can be found at **dist/coffeelicious**.

### Happy sorting!
