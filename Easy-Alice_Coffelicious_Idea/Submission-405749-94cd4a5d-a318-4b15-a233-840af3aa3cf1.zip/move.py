'''
Usege:
python3 root_path
'''

import re
import os
import sys

if __name__ == '__main__':
    if len(sys.argv) <= 1:
        print("please input the path.")
        exit()
    root_path = sys.argv[1]
    if not os.path.exists(root_path):
        print("path does not exist.")
        exit()    
    txt_files = [f for f in os.listdir(root_path) if re.match('\S+\.txt', f)]
    species_name = [f[0:-4] for f in txt_files]
    for each_specie in species_name:
        img_path = os.path.join(root_path, 'e-commerce/coffee/{}/images'.format(each_specie))
        if not os.path.exists(img_path):
            os.makedirs(img_path)
        img_files = [f for f in os.listdir(root_path) if re.match('\S+\-{}\-\S+\.png'.format(each_specie.lower()), f.lower())]
        for each_img in img_files:
            os.rename(os.path.join(root_path, each_img), os.path.join(img_path, each_img))
        
        about_path = os.path.join(root_path, 'e-commerce/coffee/{}/about'.format(each_specie))
        if not os.path.exists(about_path):
            os.makedirs(about_path)
        os.rename(os.path.join(root_path, each_specie + '.txt'), os.path.join(about_path, 'desc.txt'))
