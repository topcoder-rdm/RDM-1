import os
import pathlib
import argparse


parser = argparse.ArgumentParser()
parser.add_argument("path", help="path to file containing data")
args = parser.parse_args()

files = os.listdir(args.path)
for file in files:
    if file.endswith(".txt"):
        species = file[:file.find(".")].lower()
        folder = "./e-commerce/coffee/{}/about/".format(species)
        pathlib.Path(folder).mkdir(parents=True, exist_ok=True)
        os.rename(file, folder + file)
    if file.endswith(".png"):
        species = file.split("-")[1]
        folder = "./e-commerce/coffee/{}/images/".format(species)
        pathlib.Path(folder).mkdir(parents=True, exist_ok=True)
        os.rename(file, folder + file)
    