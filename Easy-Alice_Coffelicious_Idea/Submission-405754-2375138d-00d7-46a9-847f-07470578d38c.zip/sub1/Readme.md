# Topcoder RDM1 Easy challenge: Alice's Coffeelicious Idea

## Requirements

- Python 3 or greater

## Parameters

- `-path` or `--sourcepath`: Absolute or Relative (to python file) path for folder where all image(`.PNG`) and description(`.txt`) files are located.

## Usage

> Note: Python 3.x is required

1. Open shell and navigate to directory where `coffee-data-mover.exe` is saved.
2. Execute the following command, where {SPATH} is path ( Absolute or Relative ) to the folder in which image and description files are present
   ```
    $ python ./coffee-data-mover.py -path "{SPATH}"
   ```
