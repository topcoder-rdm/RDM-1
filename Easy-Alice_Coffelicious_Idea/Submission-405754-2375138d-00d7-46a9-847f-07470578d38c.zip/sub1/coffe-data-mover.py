import argparse
import os
import glob
import shutil


class ArgumentParser(argparse.ArgumentParser):
    # Custom Argument Parser
    def print_help(self):
        print("""
        Coffee Data Mover v1.0

        Available Commands
            -h or --help:               Provide information about the CLI
            -path or --sourcepath:      Path to folder where download files are stored

        Usage
            
            1. Open shell and navigate to directory where `coffee-data-mover.exe` is saved.
            2. Execute the following command, where {SPATH} is path ( Absolute or Relative ) to the folder in which image and description files are present

                $ python ./coffee-data-mover -path "{SPATH}"

        """)


ap = ArgumentParser(add_help=False)

# CLI Argument for Source Path
ap.add_argument("-path ", "--sourcepath", required=True,
                help="Path to directory where all files are stored")

ap.add_argument("-h ", "--help", action='help', default=argparse.SUPPRESS,
                help="Help for CLI")

args = vars(ap.parse_args())


# Create Folders for give coffee specie
def createSpeciesFolders(species):
    try:
        os.mkdir(f'./{species}')
    except FileExistsError:
        print(f'Folder ./{species} already exists. ')

    try:
        os.mkdir(f'./{species}/images')
    except FileExistsError:
        print(f'Folder ./{species}/images already exists. ')

    try:
        os.mkdir(f'./{species}/about')
    except FileExistsError:
        print(f'Folder ./{species}/about already exists. ')


if args['sourcepath']:
    # Reading Directory Contents using glob
    os.chdir(args['sourcepath'])

    # Creating folders and Moving text description file
    # This CLI skips moving if folder/file with same name exists
    for file in glob.glob("*.txt"):
        species = file.split('.')[0].lower()

        createSpeciesFolders(species)

        try:
            shutil.move(f'./{file}', f'./{species}/about/desc.txt')
        except shutil.Error:
            print(f'./{species}/about/desc.txt already exists. ')

    # Moving png file
    for file in glob.glob('*.png'):
        species = file.split('-')[1].lower()
        try:
            shutil.move(f'./{file}', f'./{species}/images/{file}')
        except shutil.Error:
            print(f'./{species}/images/{file} already exists. ')

    print("\nMoved all files!")
