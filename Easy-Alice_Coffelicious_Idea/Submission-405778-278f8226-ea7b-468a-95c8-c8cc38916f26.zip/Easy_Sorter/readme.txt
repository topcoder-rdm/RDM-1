Hello.
In order to use this file sorter, please run from your terminal.
Put the path to folder where your unsorted files exist in the -path argument
(e.g. python3 sort.py -path=/home/alice/Downloads)