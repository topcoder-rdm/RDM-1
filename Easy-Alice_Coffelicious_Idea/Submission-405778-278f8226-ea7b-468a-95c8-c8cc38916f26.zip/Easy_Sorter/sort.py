#import statements
import os, sys
from shutil import copyfile

#Check arguments
missing = True
for arg in sys.argv:
    if "-path" in arg:
        dlPath = arg.split("=")[1]
        os.chdir(dlPath)
        missing = False
if missing:
    print("Needs a -path argument")
    exit()

#Check that the folder exists otherwise make one
if os.path.isdir(os.path.join(dlPath, "e-commerce")):
    if os.path.isdir(os.path.join(dlPath, "e-commerce", "coffee")):
        pass
    else:
        os.mkdir(os.path.join(dlPath, "e-commerce", "coffee"))
else:
    os.mkdir(os.path.join(dlPath, "e-commerce"))
    os.mkdir(os.path.join(dlPath, "e-commerce", "coffee"))

#initialize variables
sortedPath = os.path.join(dlPath, "e-commerce", "coffee")
species = ""
newList = os.listdir(sortedPath)

#get the list of files to sort
fList = os.listdir(dlPath)
for curFile in fList:
    #check if the file is .txt or .png
    if ".txt" in curFile.lower():
        #txt file processing
        species = curFile.lower().split(".")[0]
        if species in newList:
            pass
        else:
            os.mkdir(os.path.join(sortedPath, species))
            os.mkdir(os.path.join(sortedPath, species, "images"))
            os.mkdir(os.path.join(sortedPath, species, "about"))
            newList.append(species)
        copyfile(os.path.join(dlPath, curFile), os.path.join(sortedPath, species, "about", "desc.txt"))
    elif ".png" in curFile.lower():
        #png file processing
        species = curFile.lower().split("-")[1]
        if species in newList:
            pass
        else:
            os.mkdir(os.path.join(sortedPath, species))
            os.mkdir(os.path.join(sortedPath, species, "images"))
            os.mkdir(os.path.join(sortedPath, species, "about"))
            newList.append(species)
        copyfile(os.path.join(dlPath, curFile), os.path.join(sortedPath, species, "images", curFile))
print("All Done!")