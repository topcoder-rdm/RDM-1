#!/usr/bin/python3

import glob
import os
import pathlib
import sys

# Ensure program is called with correct argument, and get the path from command line argument and make sure it exists
if (len(sys.argv) != 2):
    print("Usage: ", sys.argv[0], " <path to data folder>")
    exit(1)
root = sys.argv[1]
if not os.path.exists(root):
    print("Directory not found: ", root)
    exit(2)

def is_valid_image_filename(filename):
    return len(filename.split('-')) == 3

def get_species_from_image_filename(filename):
    return filename.split('-')[1].lower()

def mkdir_if_not_exist(path):
    if not os.path.exists(path):
        os.makedirs(path)

# All available coffee species (in lowercase)
all_species = set()

# For each species found in the text file, prepare the folder structure and copy over the description file
for f in glob.glob(root+"/*.txt"):
    p = pathlib.Path(f)
    filename = p.stem
    species = filename.lower()
    all_species.add(species)
    mkdir_if_not_exist(root+"/"+species+"/about")
    mkdir_if_not_exist(root+"/"+species+"/images")
    os.rename(f, root+"/"+species+"/about/desc.txt")

for f in glob.glob(root+"/*.png"):
    p = pathlib.Path(f)
    filename = p.stem
    if is_valid_image_filename(filename):
        species = get_species_from_image_filename(filename)
        # Only move the image if we had description file for the species
        if species in all_species:
            os.rename(f, root+"/"+species+"/images/"+filename+".png")

