Solution requires python 3 to run.
Usage:
python3 solution.py <path>
