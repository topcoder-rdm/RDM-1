﻿using System;
using System.IO;

public class Coffee
{
    public void Arrange(string path)
    {
        int i, n;
        string name, tn, mtn;
        string[] files;
        Directory.CreateDirectory(path + "/e-commerce");
        Directory.CreateDirectory(path + "/e-commerce/coffee");
        files = Directory.GetFiles(path, "*.txt");
        n = files.Length;
        for (i = 0; i < n; i++)
        {
            name = Path.GetFileNameWithoutExtension(files[i]);
            Directory.CreateDirectory(path + "/e-commerce/coffee/" + name);
            Directory.CreateDirectory(path + "/e-commerce/coffee/" + name + "/about");
            Directory.CreateDirectory(path + "/e-commerce/coffee/" + name + "/images");
            File.Move(files[i], path + "/e-commerce/coffee/" + name + "/about/" + Path.GetFileName(files[i]));
        }
        files = Directory.GetFiles(path, "*.png");
        for (i = 0; i < files.Length; i++)
        {
            name = Path.GetFileNameWithoutExtension(files[i]);
            tn = name.Split('-')[1];
            mtn = Char.ToUpper(tn[0]) + tn.Substring(1);
            if (!Directory.Exists(path + "/e-commerce/coffee/" + mtn))
            {
                Directory.CreateDirectory(path + "/e-commerce/coffee/" + mtn);
                Directory.CreateDirectory(path + "/e-commerce/coffee/" + mtn + "/about");
                Directory.CreateDirectory(path + "/e-commerce/coffee/" + mtn + "/images");
            }
        File.Move(files[i], path + "/e-commerce/coffee/" + mtn + "/images/" + Path.GetFileName(files[i]));
        }
    }

    static void Main(string[] args)
    {
        if (args.Length < 2)
            Console.WriteLine("Please enter the path of the download folder.");
        else if (args.Length > 2)
            Console.WriteLine("Too many arguments.");
        else if (args[0].ToLower() != "-path")
            Console.WriteLine("Please enter the path of the download folder using -path.");
        else if (!Directory.Exists(args[1]))
            Console.WriteLine("Path deoesn't exist.");
        else
        {
            Coffee z = new Coffee();
            z.Arrange(args[1]);
        }
    }
}
