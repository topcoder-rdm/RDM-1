RDM1

Easy task:
The main class is Mover
Run this class like:
java Mover -p E:\temp\RDM
Then all png and txt files will be sorted into subfolders.