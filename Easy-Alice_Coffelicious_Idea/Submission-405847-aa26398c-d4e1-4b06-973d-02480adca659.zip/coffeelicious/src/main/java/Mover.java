import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;


public class Mover 
{
	private static void move(String path) {
		File folder = new File(path);
		//check if input path is a directory
		if (!folder.isDirectory()) {
			System.err.println("Input path must be a directory");
			return;
		}
		for (File file : folder.listFiles()) {
			String filename = file.getName();
			if (!file.isFile()) continue;
			//deal with only png and txt files
			if (!filename.endsWith("png") && !filename.endsWith("txt")) {
				continue;
			}
			System.out.println("moving "+filename);
			String specName = "";  //name of species
			if (filename.endsWith("png")) {
				specName = filename.substring(filename.indexOf("-")+1, filename.lastIndexOf("-"));
			} else {
				//ends with txt
				specName = filename.substring(0, filename.indexOf("."));
			}
			specName = specName.trim().toLowerCase();
			System.out.println("species name = "+specName);
			String subfolderName = folder.getAbsolutePath()+"/"+specName;
			//make image subfolder and about subfolder
			File imageFolder = new File(subfolderName+"/images");
			File aboutFolder = new File(subfolderName+"/about");
			if (!imageFolder.exists()) {
				imageFolder.mkdirs();
			}
			if (!aboutFolder.exists()) {
				aboutFolder.mkdirs();
			}
			Path targetPath;
			if (filename.endsWith("png")) {
				targetPath = Paths.get(imageFolder+"/"+filename);
			} else {
				targetPath = Paths.get(aboutFolder+"/desc.txt");
			}
			try {
				Files.move(Paths.get(file.getAbsolutePath()),targetPath);
			} catch (IOException e) {
				System.out.println(e.getMessage());
			}
		}
	}
	public static void main(String[] args)
	{
		Options options = new Options();
		options.addOption(Option.builder("p")
				.longOpt("path")
				.hasArg(true)
				.desc(" (path of the input folder [REQUIRED] or use --path)")
				.required(true)
				.build());
		CommandLineParser parser = new DefaultParser();
		CommandLine cmd;
		try {
			cmd = parser.parse(options, args);
		} catch (ParseException e) {
			System.err.println("Cannot parse input parameter");
			return;
		}
		String path = cmd.getOptionValue("p");
		move(path);
	}
}
