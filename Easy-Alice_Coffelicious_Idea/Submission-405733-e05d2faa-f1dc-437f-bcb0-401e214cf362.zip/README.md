# Alice's Coffeelicious Idea - RDM 1 - Easy - 250 Points

## Prerequisite

- Python 3.x

## Run

Unzip the set-1-1.zip to set-1-1 path

Then run

```sh
python3 main.py --path set-1-1
```
