import argparse
import os
import shutil

def path_exists(path):
  if not os.path.exists(path) and os.path.isdir(path):
    raise argparse.ArgumentTypeError(f'No such directory {path}')
  return path

def ensure_dir(path):
  if not os.path.exists(path):
    os.makedirs(path)
  return os.path.realpath(path)

def copy_file(src_path, dst_path):
  dst_path_dir = os.path.dirname(dst_path)
  if not os.path.exists(dst_path_dir):
    os.makedirs(dst_path_dir)
  shutil.copy2(src_path, dst_path)

def move_file(src_path, dst_path):
  try:
    copy_file(src_path, dst_path)
    os.unlink(src_path)
  except:
    pass

def process(args):
  path = args.path

  species_map = {}
  for root, _, files in os.walk(path):
    for filename in files:
      fullpath = os.path.join(root, filename)
      basename = os.path.basename(fullpath)
      base_filename, ext = os.path.splitext(basename)
      base_filename = base_filename.lower()
      ext = ext.lower()
      if ext == '.txt':
        species_map[base_filename] = {
          'txt': filename,
          'images': []
        }

  for root, _, files in os.walk(path):
    for filename in files:
      fullpath = os.path.join(root, filename)
      basename = os.path.basename(fullpath)
      base_filename, ext = os.path.splitext(basename)
      base_filename = base_filename.lower()
      ext = ext.lower()
      if ext == '.png':
        split_lst = base_filename.split('-')
        for species in species_map:
          if species in split_lst:
            species_map[species]['images'].append(fullpath)

  for species, info in species_map.items():
    png_files = info['images']
    species_folder = os.path.join(path, 'e-commerce', 'coffee', species)
    ensure_dir(species_folder)
    if png_files:
      image_folder = os.path.join(species_folder, 'images')
      ensure_dir(image_folder)
      for png_file in png_files:
        move_file(png_file, image_folder)

    about_folder = os.path.join(species_folder, 'about')
    ensure_dir(about_folder)
    move_file(info['txt'], about_folder)

if __name__ == '__main__':
  parser = argparse.ArgumentParser()
  parser.add_argument('--path', required=True, type=path_exists, help='The source directory path')
  process(parser.parse_args())
