//
// Created by rakibansary on 10/10/2020.
//

#ifndef RDM_1_250_ORGANIZER_H
#define RDM_1_250_ORGANIZER_H


#include <string>
#include <utility>

class Organizer {
public:
    explicit Organizer(std::string path): PATH(std::move(path)) {}

    void organize();
private:
    std::string PATH;

    bool isImage(std::string extension) const;
    bool isTextfile(const std::string& extension) const;

    static std::string toLower(std::string);
    std::string extractSpeciesName(std::string) const;

    void initializeRootDirectory();

    void createDirectory(const std::string& path);
    void moveFile(const std::string from, const std::string to);

    const char DELIMETER = '-';
    const std::string TEXT_FILE = ".txt";
    const std::string IMAGE_FILE[1] = { ".png" };

    std::string ROOT_DIRECTORY = "e-commerce";
    std::string COFFEE_DIRECTORY = "coffee";
    std::string IMAGE_DIRECTORY = "images";
    std::string DESCRIPTION_DIRECTORY = "about";
};


#endif //RDM_1_250_ORGANIZER_H
