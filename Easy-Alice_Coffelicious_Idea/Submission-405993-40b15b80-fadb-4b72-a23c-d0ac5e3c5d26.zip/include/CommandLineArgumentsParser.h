//
// Created by rakibansary on 10/9/2020.
//

#ifndef RDM_1_250_COMMANDLINEARGUMENTSPARSER_H
#define RDM_1_250_COMMANDLINEARGUMENTSPARSER_H

#include <vector>
#include <string>

class CommandLineArgumentsParser {
public:
    CommandLineArgumentsParser(int &argc, char **argv);

    bool optionExists(const std::string &option) const;
    const std::string& getOption(const std::string &option) const;

private:
    std::vector<std::string> tokens;
};


#endif //RDM_1_250_COMMANDLINEARGUMENTSPARSER_H
