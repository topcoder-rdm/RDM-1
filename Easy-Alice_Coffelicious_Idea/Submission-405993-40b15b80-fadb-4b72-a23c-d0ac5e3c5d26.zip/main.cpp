#include <iostream>

#include "include/CommandLineArgumentsParser.h"
#include "include/Organizer.h"

using namespace std;

const auto OPTION_PATH = "-path";
const auto OPTION_HELP = "-help";
const auto OPTION_VERSION = "-version";

void showHelp();
void showVersion();

int main(int argc, char *argv[]) {
    CommandLineArgumentsParser argumentsParser(argc, argv);

    if (argumentsParser.optionExists(OPTION_PATH)) {
        string path = argumentsParser.getOption(OPTION_PATH);

        Organizer organizer(path);
        organizer.organize();
    } else if (argumentsParser.optionExists(OPTION_HELP)) {
        showHelp();
    } else if (argumentsParser.optionExists(OPTION_VERSION)) {
        showVersion();
    } else {
        showHelp();
    }

    return 0;
}

void showHelp() {
    cout << "Usage: " << OPTION_PATH << " <PATH>\nOptions:\n\t" <<
         OPTION_HELP << " Show help\t[boolean]\n\t" <<
         OPTION_VERSION << " Show version number\t[boolean]\n\t" <<
         OPTION_PATH << " PATH [string] [required]\n\n";
}

void showVersion() {
    cout << "Organizer version 0.1" << endl;
}
