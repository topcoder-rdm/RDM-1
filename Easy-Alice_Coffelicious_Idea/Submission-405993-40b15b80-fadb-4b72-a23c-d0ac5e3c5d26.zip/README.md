# Organizer

Organizer is a utility to organize files of the following format

{SPECIES_NAME}.txt
xxx_{SPECIES_NAME}_xxx.png

into 

e-commerce/coffee/{SPECIES_NAME}/about/desc.txt
e-commerce/coffee/{SPECIES_NAME}/images/xxx_{SPECIES_NAME}_xxx.png

## Building

1. Requirements

- cmake version 3.16 or greater
- Any C++ compiler

2. Building

- unzip the contents of the folder and open a terminal to it
- create a directory named Release (mkdir Release) and enter into it (cd Release)
- type cmake -DCMAKE_BUILD_TYPE=Release .. and hit enter
- type make and hit enter; This'll create an executable named Organizer

## Running Organizer

Usage: -path <PATH>
Options:
        -help       Show help
        -version    Show version number
        -path PATH  Organize files
        

        


