//
// Created by rakibansary on 10/9/2020.
//

#include "../include/CommandLineArgumentsParser.h"

#include <algorithm>
#include <vector>

CommandLineArgumentsParser::CommandLineArgumentsParser(int &argc, char **argv) {
    for (int i = 1; i < argc; i++) {
        this->tokens.emplace_back(argv[i]);
    }
}

const std::string &CommandLineArgumentsParser::getOption(const std::string &option) const {
    auto it = std::find(this->tokens.begin(), this->tokens.end(), option);
    if (it != this->tokens.end() && ++it != tokens.end()) {
        return *it;
    }

    static const std::string emptyString;
    return emptyString;
}

bool CommandLineArgumentsParser::optionExists(const std::string &option) const {
    return std::find(this->tokens.begin(), this->tokens.end(), option) != this->tokens.end();
}
