//
// Created by rakibansary on 10/10/2020.
//

#include <map>
#include <string>
#include <vector>
#include <iostream>
#include <filesystem>
#include <algorithm>

#include "../include/Organizer.h"

void Organizer::organize() {
    std::vector<std::string> species;

    unsigned int descriptionMoveCount = 0, imageMoveCount = 0, failureCount = 0;

    initializeRootDirectory();
    const std::string root = ROOT_DIRECTORY + "/" + COFFEE_DIRECTORY;

    std::map<std::string, std::vector<std::string>> images;
    std::map<std::string, std::string> description;

    for (auto &entry: std::filesystem::directory_iterator(PATH)) {
        const std::filesystem::path& p = entry;
        std::string entryExtension = p.extension().string();

        if (isTextfile(entryExtension)) {
            species.push_back(p.filename().string());
            description[p.filename().string()] = p.filename().string();
        } else if (isImage(entryExtension)) {
            images[toLower(extractSpeciesName(p.filename().string()))].push_back( p.filename().string());
        }
    }

    for (const auto& specie: species) {
        std::string key = specie;
        key.resize(key.size() - 4);
        key = toLower(key);

        createDirectory(root + "/" + key);

        const std::string descriptionDirectory = root + "/" + key + "/" + DESCRIPTION_DIRECTORY;
        createDirectory(descriptionDirectory);

        const std::string imagesDirectory = root + "/" + key + "/" + IMAGE_DIRECTORY;

        createDirectory(imagesDirectory);
        try {
            moveFile(description[specie],  descriptionDirectory + "/desc.txt");
            descriptionMoveCount++;

            for (auto &image: images[key]) {
                moveFile(image, imagesDirectory + "/" + toLower(image));
                imageMoveCount++;
            }
        }
        catch (std::filesystem::filesystem_error &e) {
            std::cout << e.what() << std::endl;
            failureCount++;
        }
    }

    std::cout << "Successfully moved " << descriptionMoveCount << " species descriptions. And " << imageMoveCount << " image files. Failure count: " << failureCount << std::endl;
}

bool Organizer::isTextfile(const std::string& extension) const {
    return extension == TEXT_FILE;
}

bool Organizer::isImage(std::string extension) const {
    for (const auto& ext: this->IMAGE_FILE) {
        if (extension == ext) {
            return true;
        }
    }
    return false;
}

std::string Organizer::toLower(std::string str) {
    std::transform(str.begin(), str.end(), str.begin(), [](unsigned char c) {
        return std::tolower(c);
    });

    return str;
}

std::string Organizer::extractSpeciesName(std::string str) const {
    unsigned int start = str.find(DELIMETER, 0);
    unsigned int end = str.find(DELIMETER, start+1);

    return str.substr(start+1, end - start - 1);
}

void Organizer::initializeRootDirectory() {
    createDirectory(ROOT_DIRECTORY);
    createDirectory(ROOT_DIRECTORY + "/" + COFFEE_DIRECTORY);
}

void Organizer::createDirectory(const std::string& path) {
    if (!std::filesystem::is_directory( PATH + "/" + path) && !std::filesystem::exists(PATH + "/" + path)) {
        std::filesystem::create_directory(PATH + "/" + path);
    }
}

void Organizer::moveFile(const std::string from, const std::string to) {
    std::filesystem::rename(PATH + "/" + from, PATH + "/" + to);
}
