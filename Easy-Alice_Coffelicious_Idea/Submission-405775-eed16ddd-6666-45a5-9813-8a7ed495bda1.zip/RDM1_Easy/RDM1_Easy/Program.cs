﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace RDM1_Easy
{
    class Solver
    {
        public void Solve(string path)
        {
            if (Directory.Exists(path)) // Check that the path is valid
            {
                // Get the list of files
                string[] fileEntries = Directory.GetFiles(path);

                // Get all the species (having extension as .txt)
                List<string> species = fileEntries.Where(x => x.ToLower().EndsWith(".txt")).ToList();

                // Other than txt, it means images
                List<string> images = fileEntries.Where(x => !x.ToLower().EndsWith(".txt")).ToList();

                // Create root directory
                string root = "e-commerce/coffee/";
                Directory.CreateDirectory(root);

                // Create folder for each species
                foreach (string file in species)
                {
                    // Remove the .txt for the species name
                    string sp = Path.GetFileNameWithoutExtension(file);
                    
                    // Create the species directory and its child
                    Directory.CreateDirectory(root + sp);
                    Directory.CreateDirectory(root + sp + "/images");
                    Directory.CreateDirectory(root + sp + "/about");
                    
                    // Move the species file and rename it as desc.txt
                    System.IO.File.Move(file, root + sp + "/about/desc.txt");                    
                }

                // Process the images
                foreach (string img in images)
                {
                    string filename = Path.GetFileName(img); // filename without path
                    string[] data = Path.GetFileNameWithoutExtension(img).Split("-"); // Split the filename to 3 parts using '-' as delimiter

                    string sp = data[1]; // species is in the second element
                    System.IO.File.Move(img, root + sp + "/images/" + filename);
                }
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Validate that it requires a path to the folder containing the files
            if (args.Length == 0)
                return;
            else
            {
                Solver solver = new Solver();
                solver.Solve(args[0]);
            }
        }
    }
}
