﻿using System;
using System.IO;

namespace AliceCoffee
{

    class Program
    {
        static void Main(string[] args)
        {

            Console.Write("Enter a path :");
            String path = Console.ReadLine();
            PathCheck(path);
            Console.ReadLine();

        }
        static void PathCheck(string path)
        {
            //Check if the directory for the provide path is exist 
            if (Directory.Exists(path))
            {
                ProcessFiles(path);
            }
            else
            {
                Console.WriteLine("{0} is not a directory", path);
            }
        }
        static void ProcessFiles(string path)
        {
            try
            {
                //Will create path to folder of coffee catogery 
                string[] fileEntries = Directory.GetFiles(path, "*.txt");
                string[] imageEntries = Directory.GetFiles(path, "*.png");
                string folderEcommerce = Path.Combine(path, "e-commerce");  // string will be the following --> / user path /e-commerce
                string folderCoffee = Path.Combine(folderEcommerce, "coffee");  // string will be the following -->  e-commerce/coffee

                //Go through the all txt files within the provided path .
                foreach (string fileName in fileEntries)
                {

                    string folderCoffeeName = Path.Combine(folderCoffee, Path.GetFileNameWithoutExtension(fileName));// string will be the following --> e-commerce/coffee/{species} folder
                    string folderAbout = Path.Combine(folderCoffeeName, "about"); // string will be the following --> e-commerce/coffee/{species}/about folder
                    string folderImage = Path.Combine(folderCoffeeName, "images");// string will be the following --> e-commerce/coffee/{species}/images

                    string imageString = "-" + Path.GetFileNameWithoutExtension(fileName) + "-";
                    imageString = imageString.ToLower();

                    //Create a folder for each coffee catogery and move files (txt & png ) from main path .
                    if (!Directory.Exists(folderAbout))
                    {
                        string destFile = Path.Combine(folderAbout, "desc.txt");
                        Directory.CreateDirectory(folderAbout);

                        Directory.Move(fileName, destFile);

                        foreach (string imageName in imageEntries)
                        {

                            string imageText = Path.GetFileNameWithoutExtension(imageName); //extract the image name from Main path
                            string destImage = Path.Combine(folderImage, imageText);//Will be used to move the image with same name  to destination folder
                            if (imageText.Contains(imageString))
                            {
                                Directory.CreateDirectory(folderImage);
                                Directory.Move(imageName, destImage);
                            }
                        }
                    Console.WriteLine("Finished successfully moving {0}", Path.GetFileNameWithoutExtension(fileName));
                    }
                    else
                    {
                        Console.WriteLine("Something wrong  in {0}.", Path.GetFileNameWithoutExtension(fileName));
                    }

                   



                }
            }
            catch(Exception e)
            {
                Console.WriteLine(e);
            }
 



        }
    }
}
