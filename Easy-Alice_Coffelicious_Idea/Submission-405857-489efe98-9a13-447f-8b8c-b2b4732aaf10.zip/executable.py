#import the necessary libs
import os, argparse, pathlib

#function to re-arrange the files in the given directory
def rearrangeFiles(path):
    #create a set to store directory names
    dirNameSet = set()
    
    #iterate over all the files in the given directory to create folders
    for filePath in os.listdir(path):
        #get file name and extension from the path
        fileNameWithExtension = os.path.basename(filePath)
        fileName, fileExtension = os.path.splitext(fileNameWithExtension)

        #make directories
        if(fileExtension == ".txt"):
            #join filename and path to get new directory
            newDir = os.path.join(path, fileName)

            #add the dir name to set
            dirNameSet.add(fileName.lower())
            
            #check if the dirs already exists or not
            if not os.path.exists(newDir):
                #make the appropriate directories
                os.mkdir(newDir)    #parent directory
                os.mkdir(os.path.join(newDir, "about")) #description files dir
                os.mkdir(os.path.join(newDir, "images"))    #image files dir
            #if yes than raise error
            else:
                print("This coffee detail already exists")

    #iterate over all the files to move them to their particular destinations
    for filePath in os.listdir(path):
        #get file name and extension from the path
        fileNameWithExtension = os.path.basename(filePath)
        fileName, fileExtension = os.path.splitext(fileNameWithExtension)
        
        #transfer description files to about folder  
        if(fileExtension == ".txt"):
            #join filename and path to get new directory
            newDir = os.path.join(path, fileName)
            
            descDirLocation = os.path.join(newDir, "about")
            descFileLocation = os.path.join(descDirLocation, "desc.txt")
            os.replace(os.path.join(path, filePath), descFileLocation)

        #transfer image files to images folder
        if(fileExtension == ".png"):
            #find the right directory for this image
            imageNameSet = set(fileName.split("-"))
            imageDirNameSet = imageNameSet & dirNameSet
            imageDirName = ''.join(imageDirNameSet)
            
            #join filename and path to get new directory
            newDir = os.path.join(path, imageDirName)
            
            descDirLocation = os.path.join(newDir, "images")
            descFileLocation = os.path.join(descDirLocation, fileNameWithExtension)
            os.replace(os.path.join(path, filePath), descFileLocation)

if __name__ == "__main__":
    #get the path from cmd
    parser = argparse.ArgumentParser()
    parser.add_argument("-path", help="directory path")
    args = parser.parse_args();

    #call the function to re-arrange the directory
    rearrangeFiles(args.path)
