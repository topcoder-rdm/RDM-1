No external libraries are used in this project.
To run this file:
1. Enter into command line.
2. Type following command:
	$python executable.py -path Directory_path
Example Command: $python executable.py -path e-commerce/coffee
3. Please give absolute path of the directory while running the file.