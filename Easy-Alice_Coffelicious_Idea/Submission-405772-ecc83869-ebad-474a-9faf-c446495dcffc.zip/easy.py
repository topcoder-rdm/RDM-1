#!/usr/bin/env python3

import sys
import os
import shutil

def solve(file_path):
    files = getFiles(file_path)
    spiecies = []
    for file in files:
        if file[-4:] == ".txt":
            spiecies.append(file[:-4].lower())

    create_directories(file_path, spiecies)
    copy_files(file_path, files, spiecies)
    remove_all(file_path, files)

def getFiles(file_path):
    try:
        return os.listdir(file_path)
    except:
        print("Directory not found. Please check path parameter")
        exit()

def create_directories(file_path, spiecies):
    for s in spiecies:
        os.makedirs("{}/e-commerce/coffee/{}/images/".format(file_path, s), exist_ok = True)
        os.makedirs("{}/e-commerce/coffee/{}/about/".format(file_path, s), exist_ok = True)

def copy_files(file_path, files, spiecies):
    for file in files:
        exist_file_path = file_path + "/" + file
        if file[-4:] == ".txt":
            shutil.copyfile(exist_file_path, "{}/e-commerce/coffee/{}/about/{}".format(file_path, file[:-4].lower(), file))
        if file[-4:] == ".png":
            splitFileName = file.split("-")
            for name in splitFileName:
                if name in spiecies:
                    shutil.copyfile(exist_file_path, "{}/e-commerce/coffee/{}/images/{}".format(file_path, name, file))

def remove_all(file_path, files):
    for file in files:
        if os.path.isfile(file_path + "/" + file):
            os.remove(file_path + "/" + file)

if __name__ == '__main__':
    if len(sys.argv) != 3:
        print("-path or path parameter not found. please use -path {directoryName} ")
        exit()
    if sys.argv[1] != "-path":
        print("-path not found. please use -path {directoryName} ")
        exit()
    solve(sys.argv[2])
