# RDM easy
## Prerequisites
* Python 3.6
  * requirements packages
    * os, sys, shutil

## Local test

```
python easy.py -path ./set-1-1
```
