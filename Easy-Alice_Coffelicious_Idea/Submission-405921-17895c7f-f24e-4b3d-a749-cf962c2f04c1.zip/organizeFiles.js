const fs = require("fs");
let path = process.argv[2];

const OrganizeFiles = (path) => {
  const getFilesInfo = (path) => {
    try {
      if (!fs.existsSync(path)) {
        throw Error("The folder is not exist.");
      } else {
        const descFiles = [];
        const imgFiles = [];
        const species = [];
        const files = fs.readdirSync(path);

        files.forEach((file) => {
          const txtFileMatch = file.match(/.txt$/);
          const pngFileMatch = file.match(/.png$/);

          if (txtFileMatch) {
            descFiles.push(file);
            const specie = file.slice(0, txtFileMatch.index).toLowerCase();
            species.push(specie);
          }
          if (pngFileMatch) {
            imgFiles.push(file);
          }
        });
        if (descFiles.length === 0 && imgFiles.length === 0) {
          throw Error("There is no files to organize.");
        }
        return { path, descFiles, imgFiles, species };
      }
    } catch (error) {
      throw error;
    }
  };

  const movingFiles = (filesInfo) => {
    const { path, descFiles, imgFiles, species } = filesInfo;

    const movingFile = (oldPath, newPath, file) => {
      try {
        if (!fs.existsSync(newPath)) {
          fs.mkdirSync(newPath, { recursive: true });
        }
        fs.renameSync(oldPath + file, newPath + file);
        console.log(file + " is moved to -> " + newPath + ".");
      } catch (error) {
        throw error;
      }
    };

    species.forEach((specie) => {
      const basePath = path + "e-commerce/coffee/" + specie;
      const descFile = descFiles.filter((f) =>
        f.toLowerCase().includes(specie)
      )[0];
      const imgFile = imgFiles.filter((f) =>
        f.toLowerCase().includes(specie)
      )[0];

      const descFilePath = basePath + "/about/";
      const imgFilePath = basePath + "/images/";

      movingFile(path, descFilePath, descFile);
      movingFile(path, imgFilePath, imgFile);
    });
  };

  try {
    const filesInfo = getFilesInfo(path);
    movingFiles(filesInfo);
  } catch (error) {
    console.log("Something Wrong - " + error);
  }
};

if (!path) {
  console.log(
    "Please specify which folder to organize, example: 'node organizeFiles.js ./download/'."
  );
} else {
  path = path[-1] !== "/" ? path + "/" : path;
  OrganizeFiles(path);
}
