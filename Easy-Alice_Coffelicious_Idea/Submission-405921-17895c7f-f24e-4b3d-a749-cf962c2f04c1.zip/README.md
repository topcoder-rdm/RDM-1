# Alice's Coffeelicious Idea - RDM 1

## Please Note:

- Solution is in `organizeFiles.js` file.

- Please install `Node.js` latest version (Version 10.0.1 or above) to run the solution.

- To run the solution:

```bash
$ node organizdFiles.js #path_of_folder
```
