## Installation

### Locally:

`npm i`

### Globally:

`npm i -g .`

*Note:* You need to have node and npm installed

in the folder

## Running

### Locally:

`./index.js`

### Globally:

`arrangecoffee <path>` in folder where files need to be arranged
