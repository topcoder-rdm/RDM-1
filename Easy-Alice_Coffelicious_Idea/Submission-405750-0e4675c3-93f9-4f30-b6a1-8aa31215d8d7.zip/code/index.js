#!/usr/bin/env node

const fs = require('fs');
const path = require('path');

(() => {
  const cwd = path.join(process.cwd(), process.argv[2] || '');
  const files = fs.readdirSync(cwd).filter(name => fs.lstatSync(path.join(cwd, name)).isFile());
  const txtFiles = files.filter(file => path.extname(file) === '.txt');
  const species = txtFiles.map(file => getFileNameWithoutExt(file));
  const speciesImages = files.reduce((acc, curr) => {
    const imageExtensions = new Set(['.png']);
    const currFileExt = path.extname(curr);

    function getSpeciesNamefromImgFile(imgFile, allSpecies) {
      for (const species of allSpecies) {
        if (imgFile.indexOf(species) >= 0) {
          return species;
        }
      }
      return;
    }

    if (imageExtensions.has(currFileExt)) {
      const imgSpecies = getSpeciesNamefromImgFile(curr, species);
      if (imgSpecies) {
        imgSpecies in acc
          ? acc[imgSpecies].push(curr)
          : acc[imgSpecies] = [curr];
      } else {
        console.log(`Unable to identify species of image: ${curr}`);
      }
    }
    return acc;
  }, {});

  createDir(path.join(cwd, 'e-commerce'));

  const baseDir = path.join(cwd, 'e-commerce', 'coffee');

  createDir(baseDir);

  if (txtFiles.length > 0) {
    for (const txtFile of txtFiles) {
      const species = getFileNameWithoutExt(txtFile);
      createDir(path.join(baseDir, species))
      createDir(path.join(baseDir, species, 'about'));
      fs.renameSync(path.join(cwd, txtFile), path.join(baseDir, species, 'about', 'desc.txt'));
    }
  }

  Object.keys(speciesImages).forEach(species => {
    createDir(path.join(baseDir, species, 'images'));
    for (const speciesImg of speciesImages[species]) {
      fs.renameSync(path.join(cwd, speciesImg), path.join(baseDir, species, 'images', speciesImg));
    }
  });
})();

function getFileNameWithoutExt(file) {
  return file.substr(0, file.lastIndexOf('.'));
}

function createDir(dir) {
  if (!fs.existsSync(dir)) {
    try {
      fs.mkdirSync(dir);
    } catch (err) {
      console.log(`unable to create dir ${dir}`);
    }
    return true;
  }
}

