import shutil, os, sys

text_file_name = []
image_file_name = []

# First argument is the path of the full folder

path= sys.argv[2]

with os.scandir(path) as entries:
    
    # Read all the file names 

    for entry in entries:
        '''  if this is a text file - 
              1. we need to save the file name so that we can create folder name with this for images

              2. We need to put this text file in a specific folder 
            
        ''' 
        if entry.name.find(".txt") != -1:
        	name = entry.name[:-4]        	
        	text_file_name.append(name)

        	# 2. create a folder

        	dir_name =path+"/e-commerce/coffee/"+name+"/about/" 
        	os.makedirs(dir_name)

        	# Copy the text file to that previous folder
        	shutil.copy(path+"/"+entry.name, dir_name)
        elif entry.name.find(".png") != -1: 
        	name = entry.name[:-4]        	
        	image_file_name.append(name)

for image_name in image_file_name:
	# we need to find the partial match coffee name from text_file_name in this image name
	for coffee_name in text_file_name:
		if image_name.lower().find(coffee_name.lower()) != -1: 
			
			# we need to create a folder under this coffee_name for image 
			dir_name =path+"/e-commerce/coffee/"+coffee_name+"/images/"
			os.makedirs(dir_name)

			# Now copy the file to that folder
			shutil.copy(path+"/"+image_name+'.png', dir_name)
 