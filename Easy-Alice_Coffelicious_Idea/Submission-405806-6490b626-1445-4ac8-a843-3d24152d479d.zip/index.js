const path = require('path');
const fs = require('fs');
const _ = require('lodash');
const mkdirp = require('mkdirp');
const mv = require('mv');
const cliArgs = require('command-line-args');

const main = () => {
  const opts = cliArgs([{ name: 'src', type: String, required: true }]);

  if (!opts.src) {
    console.error(`
      Please provide source directory path in argument "src"
      Usage : node index.js --src <ABSOLUTE_PATH_TO_DIRECTORY>
    `)
    process.exit(1);
  }

  const dataDir = opts.src;
  const files = fs.readdirSync(dataDir);
  const pngs = _.filter(files, f => f.endsWith('png'));
  const txts = _.filter(files, f => f.endsWith('txt'));

  const basePath = path.join(dataDir, 'e-commerce/coffee');
  console.log('Creating base directory for sorting : ', basePath)
  mkdirp.sync(basePath);

  console.log(`Sorting ${txts.length} species with ${pngs.length} images...`);
  _.each(txts, (txt, i) => {
    console.log(`Sorting species # ${i+1} of ${txts.length}...`);
    // get species & corresponding images
    const species = _.chain(txt).split('.txt').head().value().toLowerCase();
    const coffeePics = _.filter(pngs, png => _.includes(png.toLowerCase(), species));

    // create about directory & move species txt file
    const aboutDir = path.join(basePath, `${species}/about`);
    mkdirp.sync(aboutDir);
    const txtOldPath = path.join(dataDir, txt);
    const txtNewPath = path.join(aboutDir, 'desc.txt');
    mv(txtOldPath, txtNewPath, {mkdirp: true}, () => {});
    
    // create coffee images directory & move images
    const imgDir = path.join(basePath, `${species}/images`);
    mkdirp.sync(imgDir);
    _.each(coffeePics, pic => {
      const imgOldPath = path.join(dataDir, pic);
      const imgNewPath = path.join(imgDir, pic);
      mv(imgOldPath, imgNewPath, {mkdirp: true}, () => {});
    });
  });
};

main();
