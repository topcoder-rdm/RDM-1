# Alice's Coffeelicious Idea - RDM 1 - Easy - 250 Points

## Prerequisites
- Node v12+

## How to run?
- Install dependencies:
```bash
  npm install
```
- Run the following command with correct data directory:
```bash
  node index.js --src <ABSOLUTE-PATH-TO-SRC-DIR>
```
