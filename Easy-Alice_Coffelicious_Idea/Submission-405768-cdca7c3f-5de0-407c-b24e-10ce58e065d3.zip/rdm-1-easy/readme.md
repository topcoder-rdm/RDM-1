
## Dependencies
- node
- yarn

## Install
```
yarn
```

## Run
Path can be relative or absolute.
``
yarn run transform path/to/your/data
# example

yarn run transform data
``
