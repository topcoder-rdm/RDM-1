import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

public class Manager {

	static String folderPath;

	public static void main(String[] args) {
		if (args.length > 0)
			folderPath = args[0];
		else {
			JFileChooser chooser = new JFileChooser();
			chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
			int returnVal = chooser.showOpenDialog(null);
			if (returnVal == JFileChooser.APPROVE_OPTION) {
				folderPath = chooser.getSelectedFile().getAbsolutePath();
			} else {
				JOptionPane.showMessageDialog(null,
						"Sorry, You have not set the folder location, program will exit now");
				System.exit(0);
			}
		}

		File folder = new File(folderPath);
		File[] listOfFiles = folder.listFiles();
		ArrayList<String> CoffeeNames = new ArrayList<String>();
		Arrays.asList(listOfFiles).parallelStream().filter(file -> file.getName().endsWith(".txt")).forEach(file -> {
			String coffeeName = file.getAbsolutePath()
					.substring(file.getPath().lastIndexOf("/") + 1, file.getPath().lastIndexOf(".")).toLowerCase();
			CoffeeNames.add(coffeeName);
			String folderName = folder.getPath() + "/e-commerce/coffee/" + coffeeName + "/about";

			boolean mkdir = new File(folderName).mkdirs();
			if (mkdir) {
				moveFile(file, folderName);
			}
		});

		Arrays.asList(folder.listFiles()).stream().filter(file -> file.getName().endsWith(".png"))
				.forEachOrdered(file -> {

					CoffeeNames.forEach(coffee -> {
						if (file.getName().contains(coffee)) {
							String imageFolder = folder.getPath() + "/e-commerce/coffee/" + coffee + "/images";

							boolean mkdir = new File(imageFolder).mkdirs();
							if (mkdir)
								moveFile(file, imageFolder);
						}
					});

				});

		JOptionPane.showMessageDialog(null, "Files are organized, please check and enjoy the evening! - Byee");
	}

	private static void moveFile(File sourcefile, String destinationFolder) {
		InputStream in = null;
		OutputStream out = null;
		try {
			in = new FileInputStream(sourcefile);
			out = new FileOutputStream(destinationFolder + "/" + sourcefile.getName());

			// Copy the bits from instream to outstream
			byte[] buf = new byte[1024];
			int len;
			while ((len = in.read(buf)) > 0) {
				out.write(buf, 0, len);
			}

			sourcefile.delete();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (null != in)
					in.close();
				if (null != out)
					out.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

}
