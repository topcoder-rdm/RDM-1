Simple Java Executable has been provided

Either double click the Jar File (windows)
or use the java -jar (command)

You can either pass the folder location as the first argument or else the Folder Selection will be Opened up for you.
