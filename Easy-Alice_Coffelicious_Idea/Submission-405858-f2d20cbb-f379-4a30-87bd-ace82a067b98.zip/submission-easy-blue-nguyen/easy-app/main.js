const path = require("path");
const fs = require("fs");

// Helpers
function isExisted(checkPath) {
  return new Promise((resolve, reject) => {
    fs.access(checkPath, fs.F_OK, (err) => {
      if (err) return resolve(false);
      resolve(true);
    });
  });
}

async function createFolder(folderPath) {
  if (!(await isExisted(folderPath))) {
    return fs.promises.mkdir(folderPath, { recursive: true });
  }
}

// function copyFile(srcFile, desFile) {
//   return new Promise((resolve, reject) => {
//     fs.copyFile(srcFile, desFile, (err) => {
//       if (err) return reject(err);
//       resolve();
//     });
//   });
// }

async function main() {
  // Parse source folder and create output folders
  let source = process.argv[2];
  if (!path.isAbsolute(source)) {
    source = path.join(__dirname, source);
  }
  const output = path.join(source, "e-commerce", "coffee");
  await createFolder(output);

  // Get all files in source folder
  const files = fs
    .readdirSync(source, { withFileTypes: true })
    .filter((item) => item.isFile())
    .map((item) => item.name);
  const txtFiles = files.filter((fileName) => fileName.endsWith(".txt"));
  const imageFiles = files.filter((fileName) => fileName.endsWith(".png"));

  // Generate folder for coffee species
  const generatePromises = txtFiles.map(async (txtName) => {
    const coffeeName = txtName.substr(0, txtName.length - 4).toLowerCase();
    const coffeeFolder = path.join(output, coffeeName);
    await createFolder(coffeeFolder);
    const imageFolder = path.join(coffeeFolder, "images");
    const aboutFolder = path.join(coffeeFolder, "about");
    await createFolder(imageFolder);
    await createFolder(aboutFolder);
    const coffeeImages = imageFiles.filter((fileName) =>
      fileName.toLowerCase().includes(`-${coffeeName}-`)
    );
    const copyPromises = coffeeImages.map((fileName) => {
      const srcFile = path.join(source, fileName);
      const desFile = path.join(imageFolder, fileName);
      return fs.promises.copyFile(srcFile, desFile);
    });
    copyPromises.push(
      fs.promises.copyFile(
        path.join(source, txtName),
        path.join(aboutFolder, "desc.txt")
      )
    );
    await Promise.all(copyPromises);
    console.log(coffeeName);
  });
  await Promise.all(generatePromises);
}

main();
