# Alice's Coffeelicious Idea - RDM 1 - Easy - 250 Points

Run `node main.js -path <your path>` to test.
