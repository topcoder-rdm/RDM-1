#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os
import getopt
from shutil import copy, copyfile

def createFolderIfNotExist(folderPath):
    isFolderExists=os.path.exists(folderPath)
    if isFolderExists == False:
        os.makedirs(folderPath)

def copyFileToSpec(filePath, folderPath):
    try:
        copy(filePath, folderPath)
    except IOError as e:
        print("Unable to copy file. %s" % e)
        exit(1)
    except:
        print("Unexpected error:", sys.exc_info())
        exit(1)

if __name__ == '__main__':
    try:
      opts, args = getopt.getopt(sys.argv[1:], '', ["path="])
    except getopt.GetoptError:
      print('Usage: python main.py --path <input folder path>')
      sys.exit(2)
    folderPath = os.path.abspath(opts[0][1])
    isExists=os.path.exists(folderPath)
    if isExists == False:
        print('Foder path %s does not exist' % folderPath)
        exit(0)
    for _, _, files in os.walk(folderPath):
        for file in files:
            if file.count('-') == 2:
                fileInfo = file[0:-4].split('-')
                folderName = fileInfo[1]
                targetFolderPath = 'e-commerce/coffee/%s/images/%s' % (folderName.lower(), file)
                createFolderIfNotExist(targetFolderPath)
                copyFileToSpec(os.path.abspath(os.path.join(folderPath, file)), os.path.abspath(targetFolderPath))
            else:
                # Create folder for file if it doesn't exist
                imageFolder = 'e-commerce/coffee/%s/images/' % file[:-4].lower()
                descFolder = 'e-commerce/coffee/%s/about/' % file[:-4].lower()
                oldDescFilePath = 'e-commerce/coffee/%s/about/%s' % (file[:-4].lower(), file)
                newDescFilePath = 'e-commerce/coffee/%s/about/%s' % (file[:-4].lower(), 'desc.txt')
                createFolderIfNotExist(imageFolder)
                createFolderIfNotExist(descFolder)
                copyFileToSpec(os.path.abspath(os.path.join(folderPath, file)), os.path.abspath(descFolder))
                os.rename(os.path.abspath(oldDescFilePath),os.path.abspath(newDescFilePath))

    