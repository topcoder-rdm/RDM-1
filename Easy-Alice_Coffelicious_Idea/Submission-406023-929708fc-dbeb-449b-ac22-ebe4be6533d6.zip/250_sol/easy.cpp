#include <algorithm>
#include <filesystem>
#include <iostream>
#include <map>
#include <set>
#include <sstream>
#include <string>

using namespace std;

#if __cplusplus < 201703L // If the version of C++ is less than 17
	// It was still in the experimental:: namespace
	namespace fs = std::experimental::filesystem;
#else
	namespace fs = std::filesystem;
#endif

int output_help_message(int argc, char* argv[]) {
	// Judge whether the format of input command and parameter is correct or not.
	bool can_continue = false;
	if (argc != 3) {
		cerr << "Input parameter is insufficient: " << argc << "!" << endl;
	}
	else if (string(argv[1]) != "-path") {
		cerr << "Input parameter isn't '-path': " << argv[1] << "!" << endl;
	}
	else if (!fs::exists(string(argv[2]))) {
		cerr << "Input path doesn't exist: " << argv[2] << "!" << endl;
	}
	else {
		// Correct command format.
		can_continue = true;
	}
	if (can_continue) {
		return 0;
	}
	cerr << "usage: -path $INPUT_PATH" << endl;
	return 1;
}

int handle_image_file(const std::string& file_path,
					  const fs::path& output_path,
					  map<fs::path, fs::path>* file_to_move_list) {
	// Process ".png" file, to confirm where to move it.
	string image_name = fs::path(file_path).stem().string();
	// Parse the image file name to get the species name.
	stringstream ss(image_name);
	vector<string> split_part_list;
	string part;
	while (getline(ss, part, '-')) {
		split_part_list.push_back(part);
	}
	// Make sure the format is "xx-species-yy".
	if (split_part_list.size() != 3) {
		cerr << "Invalid image file name: " << image_name << "!" << endl;
		return 1;
	}
	string species_name = split_part_list[1];
	// Make the species name to lower case.
	transform(species_name.begin(), species_name.end(), species_name.begin(), ::tolower);
	// Record where to move the image file.
	fs::path target_path = output_path / species_name / "images" / fs::path(file_path).filename();
	(*file_to_move_list)[fs::path(file_path)] = target_path;
	return 0;
}

void handle_txt_file(const std::string& file_path,
					 const fs::path& output_path,
					 set<string>* species_set,
					 map<fs::path, fs::path>* file_to_move_list,
					 vector<fs::path>* folder_need_to_create_list) {
	// Process ".txt" file, to confirm which folder needs to be created and where to move the file.
	string species_name = fs::path(file_path).stem().string();
	// Make the species name to lower case.
	transform(species_name.begin(), species_name.end(), species_name.begin(), ::tolower);
	// Record where to move the image file.
	if (species_set->insert(species_name).second) {
		fs::path species_path(output_path / species_name);
		folder_need_to_create_list->push_back(species_path);
		folder_need_to_create_list->push_back(species_path / "images");
		folder_need_to_create_list->push_back(species_path / "about");
		(*file_to_move_list)[file_path] = species_path / "about" / "desc.txt";
	}
}

int main(int argc, char* argv[]) {
	if (output_help_message(argc, argv) != 0) {
		return 1;
	}
	fs::path input_path = string(argv[2]);
	fs::path output_path = input_path / "e-commerce/coffee";
	// A unique set including all species.
	set<string> species_set;

	// A mapping for where to move and rename files.
	map<fs::path, fs::path> file_to_move_list;

	// A list for folders to be created.
	vector<fs::path> folder_need_to_create_list;

	// Process files one by one.
	for (const auto& file_path : fs::directory_iterator(input_path)) {
		// Process files based on extension type.
		if (fs::path(file_path).extension() == ".png") {
			if (handle_image_file(fs::path(file_path).string(), output_path, &file_to_move_list) != 0) {
				return 1;
			}
		} else if (fs::path(file_path).extension() == ".txt") {
			handle_txt_file(fs::path(file_path).string(),
							output_path,
							&species_set,
							&file_to_move_list,
							&folder_need_to_create_list);
		} else {
			// There should only be ".txt" and ".png" files.
			cerr << "Illegal file extension type: " << fs::path(file_path).extension() << "!" << endl;
			return 1;
		}
	}
	// Create folders and sub-folders needed.
	for (const auto& folder : folder_need_to_create_list) {
		fs::create_directories(folder);
	}
	// Move and rename ".txt" and ".png" files.
	for (const auto& item_pair : file_to_move_list) {
		fs::rename(item_pair.first, item_pair.second);
	}
#ifdef DEBUG
	for (const auto& species_dir_path : folder_need_to_create_list) {
		cout << species_dir_path << endl;
	}

	for (const auto& move_item_pair : file_to_move_list) {
		cout << move_item_pair.first << ' ' << move_item_pair.second << endl;
	}
#endif
	return 0;
}