- Reuiqres python 3.6+
- Start with:
```
python main.py [path-to-folder]
```