import os
import argparse
import shutil
import re

# Move file to another location, creating folder if necessary
def move_file(source, dest):
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    shutil.move(source, dest)

# Get file paths within a folder
def get_paths(folderPath):
    for dirpath, _, filenames in os.walk(folderPath):
        for name in filenames:
            yield os.path.join(dirpath, name)


if __name__ == "__main__":
    # Parse arguments
    parser = argparse.ArgumentParser(description='Rearrange directory')
    parser.add_argument('path', type=str, help='Path to folder to process')
    args = parser.parse_args()

    # Process folder
    files = get_paths(args.path)

    for path in files:
        filename = os.path.basename(path)

        if path.lower().endswith('.txt'):
            species = os.path.splitext(path)[0]
            dest = os.path.join(args.path, species, 'about', filename)
        else:
            species = re.search('-([^-]+)-', filename).group(1)
            dest = os.path.join(args.path, species, 'images', filename)

        move_file(path, dest)
